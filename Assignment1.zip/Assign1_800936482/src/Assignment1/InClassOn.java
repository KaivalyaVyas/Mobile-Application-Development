package Assignment1;


//Assignment 1
//Kaivalya Vyas
//student id 800936482


import java.util.ArrayList;
import java.util.HashSet;

public class InClassOn {
	
	public static void main(String[] args)
	{
		//System.out.println("in main method user class");
		
		}
	public void parseMovie(String s)
	{
		
		double amount;
		int year;
        String name;		
		//System.out.println("in parse movie method class user");
		String[] resultingTokens = s.split(",");
		for (int i =0; i < resultingTokens.length; i++){
		
		
			
		}
	}

}
