package Assignment1;

//Assignment 1
//Kaivalya Vyas
//student id 800936482

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;



public class Movie {

	public static void main(String[] args)
	{
		Movie m = new Movie();
		m.readFileAtPath("topmovies.csv");
	}
	
	String Name;
	//int year;
	double totalIncome;
	ArrayList<String> movie = new ArrayList();
	ArrayList year = new ArrayList();
	ArrayList income = new ArrayList();
	
	public ArrayList readFileAtPath(String filename) {
		
		//ArrayList movie = new ArrayList();
		//ArrayList year = new ArrayList();
		//ArrayList income = new ArrayList();
		
		if (filename == null || filename.isEmpty()) {
	//	System.out.println("Invalid File Path");
		return movie;
		}
		String filePath = System.getProperty("user.dir") + "/" + filename;
		BufferedReader inputStream = null;
		// We need a try catch block so we can handle any potential IO errors
		try {
		try {
		inputStream = new BufferedReader(new FileReader(filePath));
		String lineContent = null;
		// Loop will iterate over each line within the file.
		// It will stop when no new lines are found.
		
		while ((lineContent = inputStream.readLine()) != null) {
			
		//System.out.println("Found the line: " + lineContent);
			//int k = 0;
       //	line.add(k,inputStream.readLine());
     //  	Collections.sort(line);
		//Split code starts here
		String[] resultingTokens = lineContent.split(",");
		
		for (int i =0; i < resultingTokens.length; i++){
			int k = 0;
			//System.out.println(resultingTokens [i].trim());
			
			if(i == 0)
			{
				movie.add(k,resultingTokens [i].trim());
			}
			else if (i == 1)
			{
				year.add(k,resultingTokens [i].trim());
			}
			
			else if(i ==2)
			{
				income.add(k,resultingTokens [i].trim());
			
			}
			k++;
			
	}
       Collections.sort(income);
       
       for(int j = 0;j <=income.size();j++)
       {
    	   System.out.println(""+movie.toString());
       }
		
		//Split Code ends here
		
		}
		}
		// Make sure we close the buffered reader.
		finally {
		if (inputStream != null)
		inputStream.close();
		}
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		return movie;
		}// end of met
	
	
}
