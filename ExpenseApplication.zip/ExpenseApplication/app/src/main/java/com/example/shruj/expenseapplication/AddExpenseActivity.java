package com.example.shruj.expenseapplication;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.Firebase;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AddExpenseActivity extends AppCompatActivity {

    TextView name;
    TextView Amount;
    TextView date;
    Firebase root;
    String name1, amount1, date1, category1, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);
        Calendar calendar = Calendar.getInstance();

        final Spinner spinner = (Spinner) findViewById(R.id.ExpenseCategory);
        name = (EditText) findViewById(R.id.ExpenseName);
        Amount = (EditText) findViewById(R.id.ExpenseAmount);
        date = (EditText) findViewById(R.id.ExpenseDate);


        email = getIntent().getStringExtra("EMAIL");


        final List<String> categories = new ArrayList<>();
        categories.add("Groceries");
        categories.add("Invoice");
        categories.add("Transportation");
        categories.add("Shopping");
        categories.add("Rent");
        categories.add("Trips");
        categories.add("Utilities");
        categories.add("Other");


        final DatePickerDialog departureDatePicker = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String year1 = String.valueOf(year);
                String month1 = String.valueOf(monthOfYear + 1);
                String day1 = String.valueOf(dayOfMonth);
                date.setText(month1 + "/" + day1 + "/" + year1);

            }
        }, calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                departureDatePicker.show();
            }
        });

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);

        Button Submit = (Button) findViewById(R.id.AddExpense_button);

        Submit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                amount1 = Amount.getText().toString();
                name1 = name.getText().toString();
                category1 = spinner.getSelectedItem().toString();
                date1 = date.getText().toString();

                if (category1 != null && name1 != null && amount1 != null && date1 != null) {
                    Expense expense = new Expense();
                    expense.setAmount(Amount.getText().toString());
                    expense.setDate(date.getText().toString());
                    expense.setName(name.getText().toString());
                    expense.setCategory(spinner.getSelectedItem().toString());
                    expense.setUser(email);
                    Log.d("demo", expense.getUser().toString());
                    root = new Firebase("https://inclass10.firebaseio.com/Expenses");
                    root.push().setValue(expense);
                    Log.d("demo", "end");
                } else {
                    Toast.makeText(getApplicationContext(), "Enter all details", Toast.LENGTH_LONG).show();
                }


            }
        });


    }
}
