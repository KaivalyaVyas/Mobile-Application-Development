package com.example.shruj.expenseapplication;

import com.firebase.client.Firebase;

/**
 * Created by shruj on 04/11/2016.
 */
public class Application extends android.app.Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Firebase.setAndroidContext(this);
    }
}
