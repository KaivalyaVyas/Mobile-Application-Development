package com.example.shruj.expenseapplication;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

/**
 * Created by shruj on 04/11/2016.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Expense implements Serializable {
    public String amount, category, date, name, email;


    public String getAmount() {
        return amount;
    }


    public Expense() {
    }

    public String getCategory() {

        return category;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUser(String user) {
        this.email = user;
    }

    public String getDate() {

        return date;
    }

    public String getName() {
        return name;
    }

    public String getUser() {
        return email;
    }


}
