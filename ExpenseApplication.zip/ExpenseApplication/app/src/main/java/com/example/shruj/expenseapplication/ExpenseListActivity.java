package com.example.shruj.expenseapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.ArrayList;

public class ExpenseListActivity extends AppCompatActivity {

    Intent intent;
    ArrayList<Expense> expenses;
    ListView expenseListView;
    Firebase root;
    String userMail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_list);

        expenses = new ArrayList<Expense>();


        Intent intent = getIntent();
        userMail = intent.getStringExtra("EMAIL");

        root = new Firebase("https://inclass10.firebaseio.com/Expenses");
        expenseListView = (ListView) findViewById(R.id.ExpenseListView);

        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                Log.d("firebase", "There are " + snapshot.getChildrenCount() + " blog posts");
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    Expense expense = postSnapshot.getValue(Expense.class);
                    if (expense.getUser().equals(userMail))
                        expenses.add(expense);
                    Log.d("firebase", expense.toString());
                }
                ExpenseAdapter adapter = new ExpenseAdapter(ExpenseListActivity.this, R.layout.row_item_list, expenses);
                expenseListView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
                Log.d("firebase", "The read failed: " + firebaseError.getMessage());
            }
        });

        expenseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ExpenseListActivity.this, ExpenseDetailActivity.class);
                intent.putExtra("expense", expenses.get(position));
                startActivity(intent);
            }
        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mymenu, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.addExpense:
                intent = new Intent(ExpenseListActivity.this, AddExpenseActivity.class);
                intent.putExtra("EMAIL", userMail);
                startActivity(intent);
                return true;
            case R.id.lgout:
                Firebase ref = new Firebase("https://inclass10.firebaseio.com/");
                ref.unauth();
                intent = new Intent(ExpenseListActivity.this, MainActivity.class);
                startActivity(intent);

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
