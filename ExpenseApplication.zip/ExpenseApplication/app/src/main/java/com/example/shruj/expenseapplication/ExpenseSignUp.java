package com.example.shruj.expenseapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

import java.util.Map;

public class ExpenseSignUp extends AppCompatActivity {

    Firebase ref = new Firebase("https://inclass10.firebaseio.com/");
    EditText editTextFullName, editTextEmail, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_sign_up);

        editTextFullName = (EditText) findViewById(R.id.editText3);
        editTextEmail = (EditText) findViewById(R.id.editText4);
        editTextPassword = (EditText) findViewById(R.id.editText5);


        findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.buttonSignUp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.createUser(editTextEmail.getText().toString(), editTextPassword.getText().toString(), new Firebase.ValueResultHandler<Map<String, Object>>() {
                    @Override
                    public void onSuccess(Map<String, Object> stringObjectMap) {
                        User user = new User(editTextEmail.getText().toString(), editTextFullName.getText().toString(), editTextPassword.getText().toString());
                        Firebase newUser = ref.child("users").child(ref.getAuth().getUid());
                        newUser.setValue(user);
                        Toast.makeText(ExpenseSignUp.this, "User has been created", Toast.LENGTH_SHORT).show();
                        finish();
                    }

                    @Override
                    public void onError(FirebaseError firebaseError) {
                        switch (firebaseError.getCode()) {
                            case FirebaseError.INVALID_EMAIL:
                                Toast.makeText(ExpenseSignUp.this, "Invalid Email", Toast.LENGTH_SHORT).show();
                                break;
                            case FirebaseError.EMAIL_TAKEN:
                                Toast.makeText(ExpenseSignUp.this, "Account not created, choose an another email id", Toast.LENGTH_SHORT).show();
                                break;
                            default:
                                Toast.makeText(ExpenseSignUp.this, "Some error happened", Toast.LENGTH_SHORT).show();
                                break;
                        }
                    }
                });
            }
        });

    }
}
