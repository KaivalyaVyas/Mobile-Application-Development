package com.example.shruj.expenseapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.AuthData;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

public class MainActivity extends AppCompatActivity {

    Firebase root;
    EditText editTextEmail, editTextPassword;
    Intent intent;
    Firebase.AuthResultHandler authResultHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextEmail = (EditText) findViewById(R.id.editText);
        editTextPassword = (EditText) findViewById(R.id.editText2);

        root = new Firebase("https://inclass10.firebaseio.com/");

        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(MainActivity.this, ExpenseSignUp.class);
                startActivity(intent);
            }
        });


        root.addAuthStateListener(new Firebase.AuthStateListener() {
            @Override
            public void onAuthStateChanged(AuthData authData) {
                if (authData != null) {
                    Intent intent = new Intent(MainActivity.this, ExpenseListActivity.class);
                    startActivity(intent);
                    finish();
                } else {

                    authResultHandler = new Firebase.AuthResultHandler() {
                        @Override
                        public void onAuthenticated(AuthData authData) {
                            Intent intent = new Intent(MainActivity.this, ExpenseListActivity.class);
                            intent.putExtra("EMAIL", editTextEmail.getText().toString());
                            startActivity(intent);
                        }

                        @Override
                        public void onAuthenticationError(FirebaseError firebaseError) {
                            Toast.makeText(MainActivity.this, "Login was not succesfull.Please try again", Toast.LENGTH_SHORT).show();
                        }
                    };
                    findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            root.authWithPassword(editTextEmail.getText().toString(), editTextPassword.getText().toString(), authResultHandler);

                        }
                    });

                }
            }
        });

    }


}
