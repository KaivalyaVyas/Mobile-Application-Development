package com.example.shruj.expenseapplication;

/**
 * Created by shruj on 04/11/2016.
 */
public class User {
    public String emailId, fullName, password;

    public User(String emailId, String fullName, String password) {
        this.emailId = emailId;
        this.fullName = fullName;
        this.password = password;
    }

    public User() {
    }


}
