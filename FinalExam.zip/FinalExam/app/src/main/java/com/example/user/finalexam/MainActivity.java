package com.example.user.finalexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.Query;
import com.firebase.client.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Adress:
                Firebase.setAndroidContext(this);
                Firebase ref = new Firebase("https://examkdv.firebaseio.com/");
                EditText adress1 =  (EditText)findViewById(R.id.Adress);
                ref.push().setValue(adress1.getText().toString());

                return true;
            case R.id.Zoom:
                //Firebase ref = new Firebase("https://stayconnectedkaivalya.firebaseio.com/users/username");
                //ref.unauth();
                //Intent intent1 = new Intent(ConversationActivity.this, MainActivity.class);
                //startActivity(intent1);


                return true;

            case R.id.Clear:
                Firebase.setAndroidContext(this);
                Firebase ref1 = new Firebase("https://examkdv.firebaseio.com/");
                ref1.removeValue();



                return true;

            default:
                return super.onOptionsItemSelected(item);
        }


    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       Button cancle = (Button)findViewById(R.id.Cancle);
       Button go = (Button)findViewById(R.id.gobutton);

     final   EditText adress =  (EditText)findViewById(R.id.Adress);

        Firebase.setAndroidContext(this);
      final  Firebase ref = new Firebase("https://examkdv.firebaseio.com/");
        // other setup code


        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (adress.getText().toString() != null) {
                    final ArrayList<String> Adress = new ArrayList<String>();
                    Query qref = ref.equalTo(adress.getText().toString());
                    qref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {

                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                String s = snapshot.getValue(String.class).toString();
                                Adress.add(s);
                                Log.d("demofoundmatchedAdres", "" + s);
                            }
                        }

                        @Override
                        public void onCancelled(FirebaseError firebaseError) {

                        }
                    });

                    Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                    intent.putStringArrayListExtra("locList", Adress);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter Adress First", Toast.LENGTH_SHORT).show();

                }

            }
        });







    }
}
