package com.example.gdao_000.hw6;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;

public class AddCityActivity extends AppCompatActivity {

    EditText edtCityName, edtState;
    static Location location;
    Intent intent;
    LocationDatabaseDataManager locationDatabaseDataManager;
    ArrayList<Location> locations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_city);

        edtCityName = (EditText) findViewById(R.id.editTextCityName);
        edtState = (EditText) findViewById(R.id.editTextState);
        locationDatabaseDataManager = new LocationDatabaseDataManager(this);

        findViewById(R.id.buttonSaveCity).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edtState.getText().toString().isEmpty() && !edtCityName.getText().toString().isEmpty()) {
                    location = new Location(edtCityName.getText().toString(), edtState.getText().toString());
                    location.setCityName(edtCityName.getText().toString());
                    location.setState(edtState.getText().toString());
                    location.setCityKey(location.getCityName(), location.getState());
                    new ValidateCityStatePair().execute(location);
                } else if (edtState.getText().toString().isEmpty())
                    edtState.setError("Mandatory Field");
                else if (edtCityName.getText().toString().isEmpty())
                    edtCityName.setError("Mandatory Field");
            }
        });
    }

    private class ValidateCityStatePair extends AsyncTask<Location, Void, String>{
        @Override
        protected String doInBackground(Location... params) {
            RequestParam requestParam = new RequestParam("GET", "http://api.sba.gov/geodata/all_data_for_city_of/");

            try {
                requestParam.addParam("city", URLEncoder.encode(params[0].getCityName(), "UTF-8"));
                requestParam.addParam("state", params[0].getState());

                try {
                    HttpURLConnection httpURLConnection = requestParam.setUpConnection();
                    int statusCode = httpURLConnection.getResponseCode();
                    if (statusCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line = bufferedReader.readLine();
                        while (line != null) {
                            stringBuilder.append(line);
                            line = bufferedReader.readLine();
                        }
                        return stringBuilder.toString();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s != null){
                if (!s.isEmpty() && s.length()>2){
                    Boolean isDuplicate = false;
                    locations = (ArrayList<Location>) locationDatabaseDataManager.getAllLocations();
                    for (Location loc: locations) {
                        if (location.getCityKey().equals(loc.getCityKey())) {
                            isDuplicate = true;
                            break;
                        }
                    }

                    if (isDuplicate == false)
                        locationDatabaseDataManager.saveLocation(location);
                    intent = new Intent(AddCityActivity.this, MainActivity.class);
                    startActivity(intent);

                }
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                return true;
            case R.id.action_clear_saved_cities:
                locationDatabaseDataManager.deleteAllLocation();
                return true;
            case R.id.action_view_note:
                Intent in = new Intent (AddCityActivity.this, ViewNoteActivity.class);
                startActivity(in);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
