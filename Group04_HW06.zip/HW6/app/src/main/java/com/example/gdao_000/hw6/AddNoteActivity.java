package com.example.gdao_000.hw6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import java.io.Serializable;
import java.util.List;

public class AddNoteActivity extends AppCompatActivity {

    NotesDatabaseDataManager notesDatabaseDataManager;
    EditText edtSaveNote;
    Notes note;
    Intent intent;
    List<Forecast> forecastList;
    Forecast forecast;
    String currentLocation;
    int currentObjectPosition;
    LocationDatabaseDataManager locationDatabaseDataManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        notesDatabaseDataManager = new NotesDatabaseDataManager(this);
        edtSaveNote = (EditText) findViewById(R.id.editTextEnterNote);

        locationDatabaseDataManager = new LocationDatabaseDataManager(this);

        intent = getIntent();
        if (intent.getExtras() != null){
            forecastList = (List<Forecast>) intent.getExtras().getSerializable("forecasts");
            currentObjectPosition = intent.getExtras().getInt("currentObject");
            currentLocation = intent.getExtras().getString("currentLocation");
        }

        forecast = forecastList.get(currentObjectPosition);

        findViewById(R.id.buttonSaveNote).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtSaveNote.getText().toString() != null) {
                    note = new Notes(forecast.getDay() + " " + forecast.getMonth(),
                            edtSaveNote.getText().toString(),
                            currentLocation);
                    notesDatabaseDataManager.saveNote(note);
                    Intent in = new Intent();
                    in.putExtra("forecasts", (Serializable) forecastList);
                    setResult(RESULT_OK, in);
                } else{
                    setResult(RESULT_CANCELED);
                }
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                intent = new Intent(AddNoteActivity.this, AddCityActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_clear_saved_cities:
                locationDatabaseDataManager.deleteAllLocation();
                intent = new Intent(AddNoteActivity.this, MainActivity.class);
                return true;
            case R.id.action_view_note:
                Intent in = new Intent (AddNoteActivity.this, ViewNoteActivity.class);
                startActivity(in);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
