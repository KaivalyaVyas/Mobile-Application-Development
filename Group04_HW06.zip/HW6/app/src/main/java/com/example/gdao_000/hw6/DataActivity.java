package com.example.gdao_000.hw6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TabHost;
import android.widget.Toast;

public class DataActivity extends AppCompatActivity {

    Intent intent;
    Location location;
    String currentLocation;
    LocationDatabaseDataManager locationDatabaseDataManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        locationDatabaseDataManager = new LocationDatabaseDataManager(this);

        TabHost host = (TabHost) findViewById(R.id.tabHost);
        host.setup();

        intent = getIntent();
        if (intent.getExtras() != null){
            location = (Location) intent.getExtras().getSerializable("locationInfo");
            currentLocation = location.currentLocationFormater(location);
        }

        TabHost.TabSpec spec = host.newTabSpec("Hourly Data");
        spec.setContent(R.id.linearLayout);
        spec.setIndicator("Hourly Data");
        new GetHourlyDataAsyncTask(this, currentLocation).execute(location);
        host.addTab(spec);

        TabHost.TabSpec spec2 = host.newTabSpec("Forecast");
        spec2.setContent(R.id.linearLayout2);
        spec2.setIndicator("Forecast");
        new Get10DayForecastAsyncTask(this, currentLocation).execute(location);
        host.addTab(spec2);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100){
            if (resultCode == RESULT_OK){
                Toast.makeText(this, "Note has been added", Toast.LENGTH_SHORT).show();
            } else if (resultCode == RESULT_CANCELED){
                Toast.makeText(this, "No note added", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                intent = new Intent(DataActivity.this, AddCityActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_clear_saved_cities:
                locationDatabaseDataManager.deleteAllLocation();
                Intent in1 = new Intent(DataActivity.this, MainActivity.class);
                startActivity(in1);
                return true;
            case R.id.action_view_note:
                Intent in = new Intent (DataActivity.this, ViewNoteActivity.class);
                startActivity(in);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
