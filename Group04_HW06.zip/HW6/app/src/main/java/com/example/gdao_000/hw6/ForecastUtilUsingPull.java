package com.example.gdao_000.hw6;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class ForecastUtilUsingPull {
    public static class ForecastPullParser {
        static List<Forecast> parseForecast(InputStream inputStream) throws XmlPullParserException, IOException {
            XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
            parser.setInput(inputStream, String.valueOf(Xml.Encoding.UTF_8));
            ArrayList<Forecast> forecastArrayList = new ArrayList<>();
            Forecast forecast = null;
            int event = parser.getEventType();

            while (event != XmlPullParser.END_DOCUMENT) {
                switch (event) {
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equalsIgnoreCase("forecast")) {
                            forecast = new Forecast();
                        } else if (parser.getName().equalsIgnoreCase("pretty")) {
                            forecast.setTime(parser.nextText().trim());
                        } else if (parser.getName().equalsIgnoreCase("temp")) {
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("english"))
                                forecast.setTemperature(parser.nextText().trim());
                        } else if (parser.getName().equals("dewpoint")) {
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("english"))
                                forecast.setDewpoint(parser.nextText().trim());
                        } else if (parser.getName().equals("condition")) {
                            forecast.setClouds(parser.nextText().toString());
                        } else if (parser.getName().equals("icon_url")) {
                            forecast.setIconUrl(parser.nextText().toString());
                        } else if (parser.getName().equals("wspd")) {
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("english"))
                                forecast.setWindSpeed(parser.nextText().trim());
                        } else if (parser.getName().equals("wdir")) {
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("dir"))
                                forecast.setWindDirection(parser.nextText().trim());
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("degrees"))
                                forecast.setWindAngle(parser.nextText().trim());
                        } else if (parser.getName().equals("wx")) {
                            forecast.setClimateType(parser.nextText().toString());
                        } else if (parser.getName().equals("humidity")) {
                            forecast.setHumidity(parser.nextText().toString());
                        } else if (parser.getName().equals("feelslike")) {
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("english"))
                                forecast.setFeelsLike(parser.nextText().trim());
                        } else if (parser.getName().equals("mslp")) {
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("english"))
                                forecast.setPressure(parser.nextText().trim());
                        } else if (parser.getName().equalsIgnoreCase("error")) {
                            forecast = new Forecast();
                            forecast.setError("error");
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals("forecast")) {
                            forecastArrayList.add(forecast);
                            forecast = null;
                        } else
                            break;
                    default:
                        break;

                }
                event = parser.next();
            }

            return forecastArrayList;
        }
    }
}
