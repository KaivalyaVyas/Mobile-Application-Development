package com.example.gdao_000.hw6;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.util.List;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class Get10DayForecastAsyncTask extends AsyncTask<Location, Integer, List<Forecast>>{

    Activity activity;
    ProgressDialog progressDialog;
    String location;
    NotesDatabaseDataManager notesDatabaseDataManager;
    Notes note;

    public Get10DayForecastAsyncTask(Activity activity, String location) {
        this.activity = activity;
        this.location = location;
    }

    @Override
    protected List<Forecast> doInBackground(Location... params) {
        RequestParam requestParam = new RequestParam("GET", "http://api.wunderground.com/api/");

        requestParam.addParam("api-key", "95977d2310997675");
        requestParam.addParam("10dayforecast", "forecast10day/q");
        requestParam.addParam("state", params[0].getState());
        requestParam.addParam("city", params[0].getCityName().replace(" ", "_"));

        try {
            HttpURLConnection httpURLConnection = requestParam.setUpConnection();
            int statusCode = httpURLConnection.getResponseCode();
            if (statusCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = httpURLConnection.getInputStream();
                return TenDayForecastUtilUsingPull.TenDayForecastPullParser.parseForecast(inputStream);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
//            Toast.makeText(activity, "No city match the query", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            activity.finish();
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Loading Forecast Data");
        progressDialog.setMax(100);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        progressDialog.setProgress(values[0]);
    }

    @Override
    protected void onPostExecute(List<Forecast> forecasts) {
        super.onPostExecute(forecasts);

        if(forecasts != null && !forecasts.isEmpty())
            set10DayDataActivityElements(forecasts);
        else{
            Toast.makeText(activity, "No city match the query", Toast.LENGTH_SHORT).show();
            activity.finish();
        }
        progressDialog.dismiss();
    }

    private void set10DayDataActivityElements(final List<Forecast> forecasts) {
        TextView textView = (TextView) activity.findViewById(R.id.textViewForecastCityValue);
        textView.setText(" " + location);

        notesDatabaseDataManager = new NotesDatabaseDataManager(activity);

        Weather10DayAdapter weather10DayAdapter = new Weather10DayAdapter(activity, R.layout.listview_10dayforecast_layout, forecasts);

        ListView listViewForecast = (ListView) activity.findViewById(R.id.listViewForecast);
        listViewForecast.setAdapter(weather10DayAdapter);

        listViewForecast.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                ImageView imageViewNote = (ImageView) view.findViewById(R.id.imageViewNote);
                imageViewNote.setVisibility(View.INVISIBLE);
                note = notesDatabaseDataManager.getNote(forecasts.get(position).getDay() + " " + forecasts.get(position).getMonth());
                notesDatabaseDataManager.deleteNote(note);
                Toast.makeText(activity, "Note has been removed", Toast.LENGTH_LONG).show();
                return false;
            }
        });

        listViewForecast.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(activity, AddNoteActivity.class);
                intent.putExtra("forecasts", (Serializable) forecasts);
                intent.putExtra("currentObject", position);
                intent.putExtra("currentLocation", location);
                activity.startActivityForResult(intent, 100);
            }
        });

        weather10DayAdapter.setNotifyOnChange(true);
    }
}
