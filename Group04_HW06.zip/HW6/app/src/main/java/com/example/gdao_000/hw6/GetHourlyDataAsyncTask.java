package com.example.gdao_000.hw6;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.util.List;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class GetHourlyDataAsyncTask extends AsyncTask<Location, Integer, List<Forecast>>{

    Activity activity;
    ProgressDialog progressDialog;
    String location;

    public GetHourlyDataAsyncTask(Activity activity, String location) {
        this.activity = activity;
        this.location = location;
    }

    @Override
    protected List<Forecast> doInBackground(Location... params) {
        RequestParam requestParam = new RequestParam("GET", "http://api.wunderground.com/api/");

        requestParam.addParam("api-key", "95977d2310997675");
        requestParam.addParam("hourly", "hourly/q");
        requestParam.addParam("state", params[0].getState());
        requestParam.addParam("city", params[0].getCityName().replace(" ", "_"));
        Log.d("demo", requestParam.toString());

        try {
            HttpURLConnection httpURLConnection = requestParam.setUpConnection();
            int statusCode = httpURLConnection.getResponseCode();
            if (statusCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = httpURLConnection.getInputStream();
                return ForecastUtilUsingPull.ForecastPullParser.parseForecast(inputStream);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            Toast.makeText(activity, "No city match the query", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            activity.finish();
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Loading Hourly Data");
        progressDialog.setMax(100);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        progressDialog.setProgress(values[0]);
    }

    @Override
    protected void onPostExecute(List<Forecast> forecasts) {
        super.onPostExecute(forecasts);
        if(forecasts != null && !forecasts.isEmpty())
            setHourlyDataActivityElements(forecasts);
        else{
            Toast.makeText(activity, "No city match the query", Toast.LENGTH_SHORT).show();
            activity.finish();
        }
        progressDialog.dismiss();
    }

    private void setHourlyDataActivityElements(final List<Forecast> forecasts){
        TextView textView = (TextView) activity.findViewById(R.id.textViewCityValue);
        textView.setText(" " +location);
        WeatherHourlyAdapter weatherAdapter = new WeatherHourlyAdapter(activity, R.layout.listview_row_layout, forecasts);

        ListView listView = (ListView) activity.findViewById(R.id.listView2);
        listView.setAdapter(weatherAdapter);
        weatherAdapter.setNotifyOnChange(true);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent in = new Intent(activity, HourlyDetailActivity.class);
                in.putExtra("listObject", (Serializable) forecasts);
                in.putExtra("currentObject", position);
                in.putExtra("currentLocation", location);
                activity.startActivity(in);
            }
        });
    }
}
