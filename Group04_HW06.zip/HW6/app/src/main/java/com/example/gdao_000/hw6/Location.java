package com.example.gdao_000.hw6;

import java.io.Serializable;

/**
 * Created by gdao_000 on 3/17/2016.
 */
public class Location implements Serializable{
    private String cityKey, cityName, state;

    public Location(String cityName, String state) {
        this.cityName = cityName;
        this.state = state;
    }

    public Location(){}

    public String getCityKey() {
        return cityKey;
    }

    public void setCityKey(String cityName, String state) {
        cityKey = cityName + "," + state;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String currentLocationFormater(Location location){
        return location.getCityName() +", " + location.getState();
    }
}
