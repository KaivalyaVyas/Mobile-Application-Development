package com.example.gdao_000.hw6;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gdao_000 on 3/17/2016.
 */
public class LocationDAO {
    private SQLiteDatabase db;

    public LocationDAO(SQLiteDatabase db) {
        this.db = db;
    }

    public long save(Location location){
        ContentValues values = new ContentValues();
        values.put(LocationTable.COLUMN_CITY_KEY, location.getCityKey());
        values.put(LocationTable.COLUMN_CITY_NAME, location.getCityName());
        values.put(LocationTable.COLUMN_STATE, location.getState());

        return db.insert(LocationTable.TABLENAME, null, values);
    }

    public boolean update(Location location){
        ContentValues values = new ContentValues();
        values.put(LocationTable.COLUMN_CITY_KEY, location.getCityKey());
        values.put(LocationTable.COLUMN_CITY_NAME, location.getCityName());
        values.put(LocationTable.COLUMN_STATE, location.getState());

        return db.update(LocationTable.TABLENAME, values, LocationTable.COLUMN_CITY_KEY + "=?", new String[]{location.getCityKey() + ""}) > 0;
    }

    public boolean delete(Location location){
        return db.delete(LocationTable.TABLENAME, LocationTable.COLUMN_CITY_KEY + "=?", new String[]{location.getCityKey() + ""}) > 0;
    }

    public boolean deleteAll(){
        return db.delete(LocationTable.TABLENAME, null, null) > 0;
    }

    public Location get(String citykey){
        Location location = null;
        Cursor c = db.query(true,
                LocationTable.TABLENAME,
                new String[]{LocationTable.COLUMN_CITY_KEY, LocationTable.COLUMN_CITY_NAME, LocationTable.COLUMN_STATE},
                LocationTable.COLUMN_CITY_KEY + "=?",
                new String[]{citykey+""},
                null, null, null, null, null);
        if (c != null && c.moveToFirst()){
            location = buildLocationFromCursor(c);
            if (!c.isClosed())
                c.close();
        }

        return location;
    }

    public List<Location> getAll(){
        List<Location> locations = new ArrayList<>();
        Cursor c = db.query(LocationTable.TABLENAME,
                new String[]{LocationTable.COLUMN_CITY_KEY,LocationTable.COLUMN_CITY_NAME, LocationTable.COLUMN_STATE},
                null, null, null, null, null);

        if (c != null && c.moveToFirst()){
            do{
                Location location = buildLocationFromCursor(c);
                if(location != null)
                    locations.add(location);
            }while (c.moveToNext());

            if (!c.isClosed())
                c.close();
        }
        return locations;
    }

    public Location buildLocationFromCursor(Cursor c){
        Location location = null;
        if (c != null){
            location = new Location();
            location.setCityKey(c.getString(1), c.getString(2));
            location.setCityName(c.getString(1));
            location.setState(c.getString(2));
        }

        return location;
    }
}
