package com.example.gdao_000.hw6;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.List;

/**
 * Created by gdao_000 on 3/17/2016.
 */
public class LocationDatabaseDataManager {
    private Context mContext;
    private LocationDatabaseOpenHelper locationDatabaseOpenHelper;
    private SQLiteDatabase db;
    private LocationDAO locationDAO;

    public LocationDatabaseDataManager(Context mContext){
        this.mContext = mContext;
        locationDatabaseOpenHelper = new LocationDatabaseOpenHelper((this.mContext));
        db = locationDatabaseOpenHelper.getWritableDatabase();
        if (db == null)
            locationDatabaseOpenHelper.onCreate(db);
        locationDAO = new LocationDAO(db);
    }

    public void close(){
        if (db != null)
            db.close();
    }

    public LocationDAO getLocationDAO(){
        return this.locationDAO;
    }

    public long saveLocation(Location location){
        return this.locationDAO.save(location);
    }

    public boolean updateLocation(Location location){
        return this.locationDAO.update(location);
    }

    public boolean deleteLocation(Location location){
        return this.locationDAO.delete(location);
    }

    public boolean deleteAllLocation(){
        return this.locationDAO.deleteAll();
    }

    public Location getLocation(String citykey){
        return this.locationDAO.get(citykey);
    }

    public List<Location> getAllLocations(){
        return this.locationDAO.getAll();
    }
}
