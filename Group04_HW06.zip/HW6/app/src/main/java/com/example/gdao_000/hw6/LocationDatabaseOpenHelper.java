package com.example.gdao_000.hw6;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by gdao_000 on 3/17/2016.
 */
public class LocationDatabaseOpenHelper extends SQLiteOpenHelper{
    static final  String LOCATION_DB_NAME = "cities.db";
    static final int LOCATION_DB_VERSION = 1;

    public LocationDatabaseOpenHelper(Context context) {
        super(context, LOCATION_DB_NAME, null, LOCATION_DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        LocationTable.onCreate(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        LocationTable.onUpgrade(db, oldVersion, newVersion);
    }
}
