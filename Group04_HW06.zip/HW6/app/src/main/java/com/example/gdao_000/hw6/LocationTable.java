package com.example.gdao_000.hw6;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by gdao_000 on 3/17/2016.
 */
public class LocationTable {
    static final String TABLENAME = "Cities";
    static final String COLUMN_CITY_KEY = "cityKey";
    static final String COLUMN_CITY_NAME = "cityName";
    static final String COLUMN_STATE = "state";

    static public void onCreate(SQLiteDatabase db){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CREATE TABLE " + TABLENAME + " (");
        stringBuilder.append(COLUMN_CITY_KEY + " text primary key, ");
        stringBuilder.append(COLUMN_CITY_NAME + " text not null, ");
        stringBuilder.append(COLUMN_STATE + " text not null);");

        db.execSQL(stringBuilder.toString());
    }

    static public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
        LocationTable.onCreate(db);
    }
}
