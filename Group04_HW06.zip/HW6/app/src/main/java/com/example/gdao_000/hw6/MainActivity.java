package com.example.gdao_000.hw6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    ListView listView;
    ArrayList<Location> locationArrayList;
    ArrayList<Notes> notesArrayList;
    ArrayList<String> locationFormatedArrayList;
    Intent intent, intent1;
    ArrayAdapter<String> arrayAdapter;
    LocationDatabaseDataManager locationDatabaseDataManager;
    NotesDatabaseDataManager notesDatabaseDataManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationDatabaseDataManager = new LocationDatabaseDataManager(this);
        notesDatabaseDataManager = new NotesDatabaseDataManager(this);

        textView = (TextView) findViewById(R.id.textViewMessage);
        listView = (ListView) findViewById(R.id.listView);


        locationArrayList = new ArrayList<>();
        locationFormatedArrayList = new ArrayList<>();
        locationArrayList = (ArrayList<Location>) locationDatabaseDataManager.getAllLocations();

        if (locationArrayList != null) {
            for (Location location : locationArrayList) {
                locationFormatedArrayList.add(location.currentLocationFormater(location));
            }
        }


        if (!locationArrayList.isEmpty()) {
            textView.setVisibility(View.INVISIBLE);
            listView.setVisibility(View.VISIBLE);
            arrayAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, locationFormatedArrayList);
            listView.setAdapter(arrayAdapter);
            arrayAdapter.setNotifyOnChange(true);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    intent1 = new Intent(MainActivity.this, DataActivity.class);
                    intent1.putExtra("locationInfo", locationArrayList.get(position));
                    startActivity(intent1);
                }
            });
        } else {
            textView.setVisibility(View.VISIBLE);
            listView.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                intent = new Intent(MainActivity.this, AddCityActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_clear_saved_cities:
                locationDatabaseDataManager.deleteAllLocation();
                textView.setVisibility(View.VISIBLE);
                listView.setVisibility(View.INVISIBLE);
                return true;
            case R.id.action_view_note:
                Intent in = new Intent (MainActivity.this, ViewNoteActivity.class);
                startActivity(in);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
