package com.example.gdao_000.hw6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by gdao_000 on 3/21/2016.
 */
public class NoteAdapter extends ArrayAdapter<Notes> {
    List<Notes> mData;
    Context mContext;
    int mResource;
    NotesDatabaseDataManager notesDatabaseDataManager;
    Notes note;

    public NoteAdapter(Context context, int resource, List<Notes> objects) {
        super(context, resource, objects);
        mData = objects;
        mContext = context;
        mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        notesDatabaseDataManager = new NotesDatabaseDataManager(mContext);

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);

            holder = new ViewHolder();
            holder.textViewNoteDate = (TextView) convertView.findViewById(R.id.textViewNoteDate);
            holder.textViewNote = (TextView) convertView.findViewById(R.id.textViewNote);
            convertView.setTag(holder);
        }

        Notes note = mData.get(position);

        holder = (ViewHolder) convertView.getTag();
        TextView textViewNoteDate = holder.textViewNoteDate;
        TextView textViewNote = holder.textViewNote;

        textViewNote.setText(note.getNote());
        textViewNoteDate.setText(note.getDate());

        return convertView;

    }

    static class ViewHolder {
        TextView textViewNoteDate;
        TextView textViewNote;
    }
}
