package com.example.gdao_000.hw6;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class Notes {
    private String date, note, citykey;

    public Notes(String date, String note, String citykey) {
        this.date = date;
        this.note = note;
        this.citykey = citykey;
    }

    public Notes(){}

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getCitykey() {
        return citykey;
    }

    public void setCitykey(String citykey) {
        this.citykey = citykey;
    }

    @Override
    public String toString() {
        return "Notes{" +
                "date='" + date + '\'' +
                ", note='" + note + '\'' +
                ", citykey='" + citykey + '\'' +
                '}';
    }
}
