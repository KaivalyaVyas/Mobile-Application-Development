package com.example.gdao_000.hw6;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class NotesDAO {
    private SQLiteDatabase db;

    public NotesDAO(SQLiteDatabase db) {
        this.db = db;
    }

    public long save (Notes note){
        ContentValues values = new ContentValues();
        values.put(NotesTable.COLUMN_DATE, note.getDate());
        values.put(NotesTable.COLUMN_NOTE, note.getNote());
        values.put(NotesTable.COLUMN_CITY_KEY, note.getCitykey());

        return db.insert(NotesTable.TABLENAME, null, values);
    }

    public boolean update(Notes note){
        ContentValues values = new ContentValues();
        values.put(NotesTable.COLUMN_DATE, note.getDate());
        values.put(NotesTable.COLUMN_NOTE, note.getNote());
        values.put(NotesTable.COLUMN_CITY_KEY, note.getCitykey());

        return db.update(NotesTable.TABLENAME, values, NotesTable.COLUMN_DATE + "=?", new String[]{note.getDate()+""}) > 0;
    }

    public boolean delete(Notes note){
        return db.delete(NotesTable.TABLENAME, NotesTable.COLUMN_DATE + "=?", new String[]{note.getDate() + ""}) > 0;
    }

    public boolean deleteAll(){
        return db.delete(NotesTable.TABLENAME, null, null) > 0;
    }

    public Notes get(String date){
        Notes note = null;
        Cursor c = db.query(true,
                NotesTable.TABLENAME,
                new String[]{NotesTable.COLUMN_DATE, NotesTable.COLUMN_NOTE, NotesTable.COLUMN_CITY_KEY},
                NotesTable.COLUMN_DATE + "=?",
                new String[]{date+""},
                null,null,null,null,null);

        if (c != null && c.moveToFirst()){
            note = buildNoteFromCursor(c);
            if (!c.isClosed())
                c.close();
        }
        return note;
    }

    public List<Notes> getAll(){
        List<Notes> notes = new ArrayList<>();
        Cursor c = db.query(NotesTable.TABLENAME,
                new String[]{NotesTable.COLUMN_DATE,NotesTable.COLUMN_NOTE, NotesTable.COLUMN_CITY_KEY},
                null,null,null,null,null);

        if (c!= null && c.moveToFirst()){
            do{
                Notes note = buildNoteFromCursor(c);
                if (note != null)
                    notes.add(note);
            }while (c.moveToNext());
            if(!c.isClosed())
                c.close();
        }
        return notes;
    }


    public Notes buildNoteFromCursor(Cursor c){
        Notes note = null;
        if (c != null){
            note = new Notes();
            note.setDate(c.getString(0));
            note.setNote(c.getString(1));
            note.setCitykey(c.getString(2));
        }
        return note;
    }
}
