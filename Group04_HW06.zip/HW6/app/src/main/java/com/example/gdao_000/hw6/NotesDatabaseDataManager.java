package com.example.gdao_000.hw6;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.List;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class NotesDatabaseDataManager {
    private Context mContext;
    private NotesDatabaseOpenHelper notesDatabaseOpenHelper;
    private SQLiteDatabase db;
    private NotesDAO notesDAO;

    public NotesDatabaseDataManager(Context mContext){
        this.mContext = mContext;
        notesDatabaseOpenHelper =  new NotesDatabaseOpenHelper(this.mContext);
        db = notesDatabaseOpenHelper.getWritableDatabase();
        if (db == null){
            notesDatabaseOpenHelper.onCreate(db);
        }
        notesDAO = new NotesDAO(db);
    }

    public void close(){
        if(db != null)
            db.close();
    }

    public NotesDAO getNotesDAO(){
        return this.notesDAO;
    }

    public long saveNote(Notes note){
        return this.notesDAO.save(note);
    }

    public boolean updateNote(Notes note){
        return this.notesDAO.update(note);
    }

    public boolean deleteNote(Notes note){
        return this.notesDAO.delete(note);
    }

    public boolean deleteAllNotes(){
        return this.notesDAO.deleteAll();
    }

    public Notes getNote(String date){
        return this.notesDAO.get(date);
    }

    public List<Notes> getAllNotes(){
        return this.notesDAO.getAll();
    }
}
