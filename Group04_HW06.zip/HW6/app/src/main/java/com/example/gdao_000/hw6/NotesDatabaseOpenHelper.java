package com.example.gdao_000.hw6;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class NotesDatabaseOpenHelper extends SQLiteOpenHelper{
    static final String NOTES_DB_NAME = "notes.db";
    static final int NOTES_DB_VERSION = 1;

    public NotesDatabaseOpenHelper(Context context) {
        super(context, NOTES_DB_NAME, null, NOTES_DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        NotesTable.onCreate(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        NotesTable.onUpgrade(db, oldVersion, newVersion);
    }
}
