package com.example.gdao_000.hw6;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class NotesTable {
    static final String TABLENAME = "notes";
    static final String COLUMN_DATE = "date";
    static final String COLUMN_NOTE = "note";
    static final String COLUMN_CITY_KEY = "citykey";

    static public void onCreate(SQLiteDatabase db){
        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE " + TABLENAME+ " (");
        sb.append(COLUMN_DATE + " text primary key, ");
        sb.append(COLUMN_NOTE + " text not null, ");
        sb.append(COLUMN_CITY_KEY + " text not null);");

        db.execSQL(sb.toString());
    }

    static public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
        NotesTable.onCreate(db);
    }
}
