package com.example.gdao_000.hw6;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class TenDayForecastUtilUsingPull {
    public static class TenDayForecastPullParser {
        static List<Forecast> parseForecast(InputStream inputStream) throws XmlPullParserException, IOException {
            XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
            parser.setInput(inputStream, String.valueOf(Xml.Encoding.UTF_8));
            ArrayList<Forecast> forecastArrayList = new ArrayList<>();
            Forecast forecast = null;
            int event = parser.getEventType();
            boolean isThing = false;

            //Need add maxwind and avehumidity
            while (event != XmlPullParser.END_DOCUMENT) {
                switch (event) {
                    case XmlPullParser.START_TAG:
                        if (parser.getName().equalsIgnoreCase("simpleforecast")) {
                            isThing = true;
                        } else if (parser.getName().equalsIgnoreCase("forecastday") && isThing == true) {
                            forecast = new Forecast();
                        } else if (isThing == true && parser.getName().equalsIgnoreCase("day")){
                            forecast.setDay(parser.nextText().trim());
                        } else if (isThing == true && parser.getName().equalsIgnoreCase("monthname")){
                            forecast.setMonth(parser.nextText().trim());
                        }else if (isThing == true && parser.getName().equalsIgnoreCase("high")){
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("fahrenheit")){
                                forecast.setHigh(parser.nextText().trim());
                            }
                        }else if (isThing == true && parser.getName().equalsIgnoreCase("low")){
                            parser.nextTag();
                            if (parser.getName().equalsIgnoreCase("fahrenheit")){
                                forecast.setLow(parser.nextText().trim());
                            }
                        }else if (isThing == true && parser.getName().equalsIgnoreCase("conditions")){
                            forecast.setClouds(parser.nextText().trim());
                        }else if (isThing == true && parser.getName().equalsIgnoreCase("icon_url")){
                            forecast.setIconUrl(parser.nextText().trim());
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        if (parser.getName().equals("forecastday") && isThing == true){
                            forecastArrayList.add(forecast);
                            forecast = null;
                        } else
                            break;
                    default:
                        break;
                }
                event = parser.next();
            }
            return forecastArrayList;
        }
    }
}
