package com.example.gdao_000.hw6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.List;

public class ViewNoteActivity extends AppCompatActivity {

    ListView listViewViewNote;
    List<Notes> notes;
    NotesDatabaseDataManager notesDatabaseDataManager;
    LocationDatabaseDataManager locationDatabaseDataManager;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_note);

        locationDatabaseDataManager = new LocationDatabaseDataManager(this);

        notesDatabaseDataManager = new NotesDatabaseDataManager(this);
        notes = notesDatabaseDataManager.getAllNotes();
        Log.d("demo", notes.toString());

        listViewViewNote = (ListView) findViewById(R.id.listViewViewNote);

        NoteAdapter noteAdapter = new NoteAdapter(this, R.layout.listview_view_note, notes);
        listViewViewNote.setAdapter(noteAdapter);
        noteAdapter.setNotifyOnChange(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_item, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                intent = new Intent(ViewNoteActivity.this, AddCityActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_clear_saved_cities:
                locationDatabaseDataManager.deleteAllLocation();
                intent = new Intent (ViewNoteActivity.this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_view_note:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
