package com.example.gdao_000.hw6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by gdao_000 on 3/18/2016.
 */
public class Weather10DayAdapter extends ArrayAdapter<Forecast>{
    List<Forecast> mData;
    Context mContext;
    int mResource;
    NotesDatabaseDataManager notesDatabaseDataManager;
    Notes note;

    public Weather10DayAdapter(Context context, int resource, List<Forecast> objects) {
        super(context, resource, objects);
        mData = objects;
        mContext = context;
        mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        notesDatabaseDataManager = new NotesDatabaseDataManager(mContext);

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);

            holder = new ViewHolder();
            holder.textViewDate = (TextView) convertView.findViewById(R.id.textViewDate);
            holder.textViewCon = (TextView) convertView.findViewById(R.id.textViewCon);
            holder.imageViewWeather = (ImageView) convertView.findViewById(R.id.imageViewWeather);
            holder.textViewHighLowTemp = (TextView) convertView.findViewById(R.id.textViewHighLowTemp);
            holder.imageViewNote = (ImageView) convertView.findViewById(R.id.imageViewNote);
            convertView.setTag(holder);
        }

        Forecast forecast = mData.get(position);

        holder = (ViewHolder) convertView.getTag();
        TextView textViewDate = holder.textViewDate;
        TextView textViewCon = holder.textViewCon;
        TextView textViewHighLowTemp = holder.textViewHighLowTemp;
        ImageView imageViewWeather = holder.imageViewWeather;
        ImageView imageViewNote = holder.imageViewNote;

        textViewDate.setText(forecast.getDay() + " " + forecast.getMonth());
        textViewHighLowTemp.setText(forecast.getHigh() + "℉ / " + forecast.getLow() +"℉");
        textViewCon.setText(forecast.getClouds());

        if (forecast.getIconUrl() != null) {
            Picasso.with(mContext)
                    .load(forecast.getIconUrl())
                    .fit()
                    .centerInside()
                    .into(imageViewWeather);
        }

        note = notesDatabaseDataManager.getNote(forecast.getDay() + " " + forecast.getMonth());
        if (note != null){
            imageViewNote.setVisibility(View.VISIBLE);
        }

        return convertView;

    }

    static class ViewHolder {
        ImageView imageViewNote;
        TextView textViewDate;
        TextView textViewCon;
        ImageView imageViewWeather;
        TextView textViewHighLowTemp;
    }
}
