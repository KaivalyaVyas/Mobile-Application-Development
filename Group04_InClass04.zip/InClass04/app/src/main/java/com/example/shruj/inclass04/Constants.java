package com.example.shruj.inclass04;

/**
 * Created by shruj on 02/08/2016.
 */
public class Constants {
    public static String passwordLength_KEY = "PasswordLength";
    public static String number_KEY = "Number";
    public static String specialChar_KEY = "SpecialCharacters";
    public static String lowerCase_KEY = "LowerCase";
    public static String upperCase_KEY = "UpperCase";
    public static String status = "Status";
    public static String generate = "Generate Thread";
    public static String startingMessage = "Starting Thread..";
    public static String result = "Result";
    public static String generatedPassword = "Password generated..";
    public static String failed = "Failed generating..";
    public static String generatingPassword = "Generating password..";


}
