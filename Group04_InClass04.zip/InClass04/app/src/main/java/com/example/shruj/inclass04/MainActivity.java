package com.example.shruj.inclass04;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Handler handler;
    int spinnerValue = 0;
    boolean num, upper, lower, special;
    CheckBox checkBoxNumber, checkBoxUppercase, CheckBoxLowercase, CheckBoxSpecial;
    String password;
    TextView textView;
    ProgressDialog progressDialog;
    Bundle bundle;
    Spinner spinner;
    ArrayAdapter<String> dataAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = (Spinner) findViewById(R.id.spinner);
        textView = (TextView) findViewById(R.id.textView);

        List<String> categories = new ArrayList<>();
        categories.add(0, "8 - 12");
        categories.add(1, "13 - 17");
        categories.add(2, "18 - 22");


        dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner.setAdapter(dataAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinnerValue = position;
                textView.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                Log.i("message", msg.what + "");
                if (msg.what == 0x03) {


                    Log.i("message", msg.obj + "");
                    textView.setText(msg.obj.toString());
                    textView.setVisibility(View.VISIBLE);
                }


                return false;

            }
        });


        findViewById(R.id.buttonGenerateAsync).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                checkBoxNumber = (CheckBox) findViewById(R.id.checkBoxNumbers);
                num = checkBoxNumber.isChecked();
                CheckBoxSpecial = (CheckBox) findViewById(R.id.checkBoxSpecialCharacters);
                special = CheckBoxSpecial.isChecked();
                CheckBoxLowercase = (CheckBox) findViewById(R.id.checkBoxLowercase);
                lower = CheckBoxLowercase.isChecked();
                checkBoxUppercase = (CheckBox) findViewById(R.id.checkBoxUppercase);
                upper = checkBoxUppercase.isChecked();


                bundle = new Bundle();
                bundle.putInt(Constants.passwordLength_KEY, spinnerValue);
                bundle.putBoolean(Constants.number_KEY, num);
                bundle.putBoolean(Constants.lowerCase_KEY, lower);
                bundle.putBoolean(Constants.upperCase_KEY, upper);
                bundle.putBoolean(Constants.specialChar_KEY, special);

                new GeneratePassword().execute(bundle);
            }
        });

        findViewById(R.id.buttonGenerateThread).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                checkBoxNumber = (CheckBox) findViewById(R.id.checkBoxNumbers);
                num = checkBoxNumber.isChecked();
                CheckBoxSpecial = (CheckBox) findViewById(R.id.checkBoxSpecialCharacters);
                special = CheckBoxSpecial.isChecked();
                CheckBoxLowercase = (CheckBox) findViewById(R.id.checkBoxLowercase);
                lower = CheckBoxLowercase.isChecked();
                checkBoxUppercase = (CheckBox) findViewById(R.id.checkBoxUppercase);
                upper = checkBoxUppercase.isChecked();


                new Thread(generatePassword, Constants.generate).start();
            }
        });
    }

    private Runnable generatePassword = new Runnable() {
        static final int STATUS_START = 0x00;
        static final int STATUS_STEP = 0x01;
        static final int STATUS_END = 0x02;
        static final int STATUS_RESULT = 0x03;

        Bundle bundle1 = new Bundle();

        private void sendMsg(String msgText) {

            Message message = new Message();
            message.obj = msgText;
            message.what = 0x03;
            handler.sendMessage(message);
        }


        @Override
        public void run() {

            try {
                password = Util.getPassword(spinnerValue, num, upper, lower, special);
                Log.d("password", password);

                sendMsg(password);


            } catch (Exception ex) {

                ex.printStackTrace();
            }

        }
    };


    public class GeneratePassword extends AsyncTask<Bundle, Integer, String> {


        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            textView.setText(s);
            textView.setVisibility(View.VISIBLE);
            progressDialog.dismiss();
        }

        @Override
        protected String doInBackground(Bundle... params) {
            int passwordLength = params[0].getInt(Constants.passwordLength_KEY);
            boolean number = params[0].getBoolean(Constants.number_KEY);
            boolean lower = params[0].getBoolean(Constants.lowerCase_KEY);
            boolean upper = params[0].getBoolean(Constants.upperCase_KEY);
            boolean special = params[0].getBoolean(Constants.specialChar_KEY);

            String password = Util.getPassword(passwordLength, number, upper, lower, special);
            return password;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.setMax(100);
            progressDialog.setCancelable(Boolean.FALSE);
            progressDialog.setMessage(Constants.generatingPassword);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.show();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);
        }
    }


}


