package com.example.shruj.nytimesapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.io.Serializable;
import java.util.List;

/**
 * Created by shruj on 03/14/2016.
 */
public class DatabaseDataManager implements Serializable {
    private Context mContext;
    private DatabaseOpenHelper dbOpenHelper;
    private SQLiteDatabase db;
    private StoriesDAO storiesDAO;

    public DatabaseDataManager(Context mContext) {
        this.mContext = mContext;
        dbOpenHelper = new DatabaseOpenHelper(this.mContext);
        db = dbOpenHelper.getWritableDatabase();
        if (db == null) {
            dbOpenHelper.onCreate(db);
        }
        storiesDAO = new StoriesDAO(db);
    }

    public void close() {
        if (db != null) {
            db.close();
        }
    }

    public StoriesDAO getStoriesDAO() {
        return this.storiesDAO;
    }

    public long saveStory(Story story) {
        return this.storiesDAO.save(story);
    }

    public boolean updateStory(Story story) {
        return this.storiesDAO.update(story);
    }

    public boolean deleteStory(Story story) {
        return this.storiesDAO.delete(story);
    }

    public boolean deleteAllStories() {
        return this.storiesDAO.deleteAll();
    }

    public Story getStory(String title) {
        return this.storiesDAO.get(title);
    }

    public List<Story> getAllStories() {
        return this.storiesDAO.getAll();
    }

}
