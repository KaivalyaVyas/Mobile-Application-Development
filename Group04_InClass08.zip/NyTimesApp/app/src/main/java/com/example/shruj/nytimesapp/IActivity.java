package com.example.shruj.nytimesapp;

import java.util.ArrayList;

/**
 * Created by shruj on 02/29/2016.
 */
public interface IActivity {
    void setListView(ArrayList<Story> stories);
}
