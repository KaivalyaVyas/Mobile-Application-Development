package com.example.shruj.nytimesapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by shruj on 03/14/2016.
 */
public class StoriesDAO {

    private SQLiteDatabase db;

    public StoriesDAO(SQLiteDatabase db) {
        this.db = db;
    }

    public long save(Story story) {

        ContentValues values = new ContentValues();
        values.put(StoryTable.COLUMN_TITLE, story.getStoryTitle());
        values.put(StoryTable.COLUMN_BYLINE, story.getStoryByLine());
        values.put(StoryTable.COLUMN_ABSTRACT, story.getStoryAbstract());
        values.put(StoryTable.COLUMN_CREATE_DATE, story.getStoryCreatedDate());
        values.put(StoryTable.COLUMN_THUMB, story.getStoryThumbImageURL());
        values.put(StoryTable.COLUMN_NORMAL, story.getStoryNormalImageURL());


        return db.insert(StoryTable.TABLENAME, null, values);
    }

    public boolean update(Story story) {

        ContentValues values = new ContentValues();
        values.put(StoryTable.COLUMN_TITLE, story.getStoryTitle());
        values.put(StoryTable.COLUMN_BYLINE, story.getStoryByLine());
        values.put(StoryTable.COLUMN_ABSTRACT, story.getStoryAbstract());
        values.put(StoryTable.COLUMN_CREATE_DATE, story.getStoryCreatedDate());
        values.put(StoryTable.COLUMN_THUMB, story.getStoryThumbImageURL());
        values.put(StoryTable.COLUMN_NORMAL, story.getStoryNormalImageURL());

        return db.update(StoryTable.TABLENAME, values, StoryTable.COLUMN_TITLE + "=?", new String[]{story.getStoryTitle()}) > 0;
    }

    public boolean delete(Story story) {
        return db.delete(StoryTable.TABLENAME, StoryTable.COLUMN_TITLE + "=?", new String[]{story.getStoryTitle()}) > 0;
    }

    public boolean deleteAll() {
        return db.delete(StoryTable.TABLENAME, null, null) > 0;
    }


    public Story get(String title) {
        Story story = null;
        Cursor c = db.query(true, StoryTable.TABLENAME, new String[]{StoryTable.COLUMN_ID, StoryTable.COLUMN_TITLE, StoryTable.COLUMN_BYLINE,
                        StoryTable.COLUMN_ABSTRACT, StoryTable.COLUMN_CREATE_DATE, StoryTable.COLUMN_THUMB, StoryTable.COLUMN_NORMAL},
                StoryTable.COLUMN_TITLE + "=?", new String[]{title}, null, null, null, null, null);

        if (c != null && c.moveToFirst()) {
            story = buildNoteFromCursor(c);
            if (!c.isClosed()) {
                c.close();
            }
        }

        return story;
    }

    public List<Story> getAll() {
        List<Story> stories = new ArrayList<>();
        Story story = null;
        Cursor c = db.query(StoryTable.TABLENAME, new String[]{StoryTable.COLUMN_ID, StoryTable.COLUMN_TITLE, StoryTable.COLUMN_BYLINE,
                        StoryTable.COLUMN_ABSTRACT, StoryTable.COLUMN_CREATE_DATE, StoryTable.COLUMN_THUMB, StoryTable.COLUMN_NORMAL},
                null, null, null, null, null);

        if (c != null && c.moveToFirst()) {
            do {
                story = buildNoteFromCursor(c);
                if (story != null)
                    stories.add(story);
            } while (c.moveToNext());
            if (!c.isClosed()) {
                c.close();
            }
        }
        return stories;
    }

    public Story buildNoteFromCursor(Cursor c) {
        Story story = null;
        if (c != null) {
            story = new Story();
            story.setStoryId(c.getLong(0));
            story.setStoryTitle(c.getString(1));
            story.setStoryByLine(c.getString(2));
            story.setStoryAbstract(c.getString(3));
            story.setStoryCreatedDate(c.getString(4));
            story.setStoryThumbImageURL(c.getString(5));
            story.setStoryNormalImageURL(c.getString(6));
        }
        return story;
    }
}


