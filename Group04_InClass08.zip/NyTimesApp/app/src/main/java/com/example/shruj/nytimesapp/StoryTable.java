package com.example.shruj.nytimesapp;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by shruj on 03/14/2016.
 */
public class StoryTable {
    static final String TABLENAME = "Stories";
    static final String COLUMN_ID = "id";
    static final String COLUMN_TITLE = "title";
    static final String COLUMN_BYLINE = "byline";
    static final String COLUMN_ABSTRACT = "abstract";
    static final String COLUMN_CREATE_DATE = "created_date";
    static final String COLUMN_THUMB = "thumb_image_url";
    static final String COLUMN_NORMAL = "normal_image_url";


    static public void onCreate(SQLiteDatabase db) {
        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE " + TABLENAME + " (");
        sb.append(COLUMN_ID + " integer  , ");
        sb.append(COLUMN_TITLE + " text primary key , ");
        sb.append(COLUMN_BYLINE + " text not null, ");
        sb.append(COLUMN_ABSTRACT + " text not null, ");
        sb.append(COLUMN_CREATE_DATE + " text not null, ");
        sb.append(COLUMN_THUMB + " text not null, ");
        sb.append(COLUMN_NORMAL + " text not null ); ");

        db.execSQL(sb.toString());
    }

    static public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLENAME);
        StoryTable.onCreate(db);
    }
}



