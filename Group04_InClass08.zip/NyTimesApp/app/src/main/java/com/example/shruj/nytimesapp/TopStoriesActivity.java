package com.example.shruj.nytimesapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class TopStoriesActivity extends AppCompatActivity implements IActivity {

    Intent intent;
    String newsItem;
    static ListView listView;
    StoryAdapter storyAdapter;
    DatabaseDataManager databaseDataManager;
    ArrayList<Story> bookmarkList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_stories);

        intent = getIntent();

        listView = (ListView) findViewById(R.id.listView);

        if (intent.getExtras() != null) {
            newsItem = intent.getExtras().getString(Constants.NEWS_ITEM);
            Log.d("demo", "topstories");
            databaseDataManager = new DatabaseDataManager(this);
            new GetNewsAsyncTask(TopStoriesActivity.this, databaseDataManager).execute(newsItem);
        }

    }

    @Override
    public void setListView(ArrayList<Story> stories) {

        for (Story story : stories) {
            Log.d("demo", story.toString());
        }

        storyAdapter = new StoryAdapter(TopStoriesActivity.this, R.layout.listview_row_item_layout, stories, databaseDataManager);
        listView.setAdapter(storyAdapter);
        storyAdapter.setNotifyOnChange(Boolean.TRUE);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                bookmarkList = (ArrayList<Story>) databaseDataManager.getAllStories();
                setListView(bookmarkList);
                return true;
            case R.id.action_about:
                databaseDataManager.deleteAllStories();
                Toast.makeText(TopStoriesActivity.this, "Bookmarks cleared", Toast.LENGTH_SHORT).show();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_item, menu);
        return true;
    }
}
