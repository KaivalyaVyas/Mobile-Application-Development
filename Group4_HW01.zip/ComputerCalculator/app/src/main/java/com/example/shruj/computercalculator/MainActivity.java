/*
 Homework Assignment - 1
 MainActivity.java
 Giang Dao
 Kaivalya Vyas
 Shrujan Kotturi
 */

package com.example.shruj.computercalculator;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int memorySize = 0;
    float storageSize = 0;
    int count = 0;
    int tipPercentage = 0;
    float tip = 1.15f;
    float delivery = 0;
    float cost = 0;

    Button buttonCalculate;
    Button buttonReset;

    RadioGroup radioGroupMemory;
    RadioGroup radioGroupStorage;
    RadioButton radioButton2GB;
    RadioButton radioButton250GB;

    CheckBox checkBoxMouse;
    CheckBox checkBoxFlashDrive;
    CheckBox checkBoxCoolingPad;
    CheckBox checkBoxCarryingCase;

    SeekBar seekBar;

    Switch switchDeliveryOption;

    TextView textViewTipPercentage;
    TextView editTextPrice;
    TextView textViewError;
    TextView textViewDeliveryStatus;

    EditText editTextDollarAmount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(Boolean.TRUE);
        actionBar.setIcon(R.drawable.ic_launcher);

        buttonCalculate = (Button) findViewById(R.id.buttonCalculate);
        buttonReset = (Button) findViewById(R.id.buttonReset);

        radioGroupMemory = (RadioGroup) findViewById(R.id.radioGroupMemory);
        radioGroupStorage = (RadioGroup) findViewById(R.id.radioGroupStorage);
        radioButton2GB = (RadioButton) findViewById(R.id.radioButton2GB);
        radioButton250GB = (RadioButton) findViewById(R.id.radioButton250GB);

        checkBoxMouse = (CheckBox) findViewById(R.id.checkBoxMouse);
        checkBoxFlashDrive = (CheckBox) findViewById(R.id.checkBoxFlashDrive);
        checkBoxCarryingCase = (CheckBox) findViewById(R.id.checkBoxCarryingCase);
        checkBoxCoolingPad = (CheckBox) findViewById(R.id.checkBoxCoolingPad);

        seekBar = (SeekBar) findViewById(R.id.seekBar);

        switchDeliveryOption = (Switch) findViewById(R.id.switchDelivery);

        textViewTipPercentage = (TextView) findViewById(R.id.textViewTipPercentage);
        textViewDeliveryStatus = (TextView) findViewById(R.id.textViewDeliveryStatus);
        textViewError = (TextView) findViewById(R.id.textViewError);

        editTextPrice = (TextView) findViewById(R.id.editTextPrice);
        editTextDollarAmount = (EditText) findViewById(R.id.editTextDollarAmount);

        seekBar.setMax(5);
        seekBar.setProgress(3);

        editTextDollarAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textViewError.setVisibility(View.INVISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tipPercentage = progress * 5;
                textViewTipPercentage.setText(tipPercentage + "%");
                tip = tipPercentage / 100.0f;
                tip++;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (setError()) {

                } else {

                    getRadioGroupMemoryInfo();
                    getRadioGroupStorageInfo();
                    getCheckBoxCount();
                    getDeliveryOption();

                    Log.d("Inside - memory", Integer.toString(memorySize));
                    Log.d("Inside - storage", Float.toString(storageSize));
                    Log.d("Inside - count", Integer.toString(count));
                    Log.d("Inside - tip", Float.toString(tip));
                    Log.d("Inside - delivery", Float.toString(delivery));


                    cost = ((memorySize + storageSize + count) * tip) + delivery;
                    cost = Math.round(cost * 100);
                    cost /= 100;
                    editTextPrice.setText(("Price: $" + Float.toString(cost)).toString());

                    if (cost <= Float.parseFloat(editTextDollarAmount.getText().toString())) {

                        textViewDeliveryStatus.setText(R.string.withinBudgetLabel);
                        textViewDeliveryStatus.setBackgroundResource(android.R.color.holo_green_light);
                        textViewDeliveryStatus.setTextColor(getResources().getColor(android.R.color.white));

                    } else if (cost > Float.parseFloat(editTextDollarAmount.getText().toString())) {

                        textViewDeliveryStatus.setText(R.string.overBudgetLabel);
                        textViewDeliveryStatus.setBackgroundResource(android.R.color.holo_red_light);
                        textViewDeliveryStatus.setTextColor(getResources().getColor(android.R.color.white));

                    }

                    textViewDeliveryStatus.setVisibility(View.VISIBLE);

                }
            }
        });

        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                textViewDeliveryStatus.setVisibility(View.INVISIBLE);
                editTextDollarAmount.setText(R.string.Space);
                radioButton2GB.setChecked(Boolean.TRUE);
                radioButton250GB.setChecked(Boolean.TRUE);
                checkBoxCoolingPad.setChecked(Boolean.FALSE);
                checkBoxFlashDrive.setChecked(Boolean.FALSE);
                checkBoxCarryingCase.setChecked(Boolean.FALSE);
                checkBoxMouse.setChecked(Boolean.FALSE);
                switchDeliveryOption.setChecked(Boolean.TRUE);
                editTextPrice.setText("Price: $0.00");
                seekBar.setProgress(3);

                memorySize = 0;
                storageSize = 0;
                count = 0;
                tipPercentage = 0;
                tip = 1.15f;
                delivery = 0;
                cost = 0;


            }
        });
    }

    private void getDeliveryOption() {
        delivery = 0;
        if (switchDeliveryOption.isChecked()) {
            delivery = 5.95f;
        }
    }

    private void getCheckBoxCount() {
        //Get the count of accesories
        count = 0;
        if (checkBoxMouse.isChecked()) {
            count++;
        }
        if (checkBoxCarryingCase.isChecked()) {
            count++;
        }
        if (checkBoxCoolingPad.isChecked()) {
            count++;
        }
        if (checkBoxFlashDrive.isChecked()) {
            count++;
        }
        count *= 20;
    }

    private void getRadioGroupStorageInfo() {
        //Storage selection
        if (radioGroupStorage.getCheckedRadioButtonId() == R.id.radioButton250GB) {
            storageSize = 250;
        } else if (radioGroupStorage.getCheckedRadioButtonId() == R.id.radioButton500GB) {
            storageSize = 500;
        } else if (radioGroupStorage.getCheckedRadioButtonId() == R.id.radioButton750GB) {
            storageSize = 750;
        } else {
            storageSize = 1024;
        }
        storageSize *= (0.75);
    }

    private void getRadioGroupMemoryInfo() {
        //Memory selection
        if (radioGroupMemory.getCheckedRadioButtonId() == R.id.radioButton2GB) {
            memorySize = 2;
        } else if (radioGroupMemory.getCheckedRadioButtonId() == R.id.radioButton4GB) {
            memorySize = 4;
        } else if (radioGroupMemory.getCheckedRadioButtonId() == R.id.radioButton8GB) {
            memorySize = 8;
        } else {
            memorySize = 16;
        }
        memorySize *= 10;
    }

    private boolean setError() {
        boolean result = Boolean.FALSE;

        if ((editTextDollarAmount.getText().toString().isEmpty()) || editTextDollarAmount.getText().toString().equals(".")) {

            result = Boolean.TRUE;
            //textViewError.setVisibility(View.VISIBLE);
            editTextDollarAmount.setError("Enter a dollar amount");
        }

        return result;
    }
}
