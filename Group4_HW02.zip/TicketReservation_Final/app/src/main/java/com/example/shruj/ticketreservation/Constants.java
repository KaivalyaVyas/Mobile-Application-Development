package com.example.shruj.ticketreservation;

/**
 * Created by shruj on 02/05/2016.
 */
public class Constants {
    public static final String sourceDestinationError = "The Source and destination can't be the same";
    public static final String sourceNullPointerError = "Source location can't be null";
    public static final String oneWayTrip = "One-way";
    public static final String roundTrip = "Round-trip";
    public static final String LinkedList_KEY = "linkedListTickets";
    public static final String LinkedListId_KEY = "linkedListId";
    public static final String titleDepartureDate = "Departure Date";
    public static final String titleReturnDate = "Return Date";
    public static final String titleReturnTime = "Return Time";
    public static final String titleDepartureTime = "Departure Time";
    public static final String dateValidationError = "Enter proper dates";
    public static final String viewArrayListOutOfBounds = "You can view tickets only after creating";
}
