/*
*
a. Assignment-2.
b. File Name- Group4_HW02.zip
c. Kaivalya Vyas, Shrujan Kotturi and Giang Dao
*
*
*
* */

package com.example.shruj.ticketreservation;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.ArrayList;

public class DeleteActivity extends AppCompatActivity {

    Intent intent;
    ArrayList<Ticket> tickets;
    Ticket ticket;

    EditText editTextName, editTextSource, editTextDestination, editTextDepartureDate, editTextDepartureTime, editTextReturnDate, editTextReturnTime;

    LinearLayout linearLayoutReturn;
    RadioGroup radioGroup;
    RadioButton radioButtonOneWay, radioButtonReturnTrip;
    AlertDialog alertDialogSource;

    CharSequence[] names;
    String tripSelected = Constants.oneWayTrip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(Boolean.TRUE);
        actionBar.setIcon(R.mipmap.ic_launcher);

        editTextName = (EditText) findViewById(R.id.editTextDeleteName);
        editTextSource = (EditText) findViewById(R.id.editTextDeleteSource);
        editTextDestination = (EditText) findViewById(R.id.editTextDeleteDestination);
        editTextDepartureDate = (EditText) findViewById(R.id.editTextDeleteDepartureDate);
        editTextDepartureTime = (EditText) findViewById(R.id.editTextDeleteDepartureTime);
        editTextReturnDate = (EditText) findViewById(R.id.editTextDeleteReturnDate);
        editTextReturnTime = (EditText) findViewById(R.id.editTextDeleteReturnTime);
        radioButtonOneWay = (RadioButton) findViewById(R.id.radioButtonDeleteOneWay);
        radioButtonReturnTrip = (RadioButton) findViewById(R.id.radioButtonDeleteRoundTrip);
        linearLayoutReturn = (LinearLayout) findViewById(R.id.linearLayoutDeleteReturn);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroupDeleteTrip);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = (RadioButton) findViewById(checkedId);
                tripSelected = radioButton.getText().toString();
                if (!tripSelected.equals(Constants.oneWayTrip)) {
                    linearLayoutReturn.setVisibility(View.VISIBLE);
                } else {
                    linearLayoutReturn.setVisibility(View.INVISIBLE);
                }
            }
        });

        findViewById(R.id.buttonDelete).setEnabled(Boolean.FALSE);

        intent = getIntent();
        if (intent.getExtras() != null) {
            tickets = (ArrayList<Ticket>) intent.getExtras().getSerializable(Constants.LinkedList_KEY);

        }
        findViewById(R.id.buttonSelectDeleteTicket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialogSource.show();
            }
        });

        AlertDialog.Builder builderSource = new AlertDialog.Builder(this);
        names = new CharSequence[tickets.size()];

        for (int i = 0; i < tickets.size(); i++) {
            names[i] = tickets.get(i).name;
        }


        builderSource.setTitle(R.string.deleteTicketsTag)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        linearLayoutReturn.setVisibility(View.INVISIBLE);
                        findViewById(R.id.buttonDelete).setEnabled(Boolean.TRUE);
                        ticket = tickets.get(which);
                        editTextName.setText(ticket.name);
                        editTextSource.setText(ticket.source);
                        editTextDestination.setText(ticket.destination);
                        editTextDepartureDate.setText(ticket.departureDate);
                        editTextDepartureTime.setText(ticket.departureTime);
                        radioButtonOneWay.setChecked(Boolean.TRUE);
                        if (ticket.tripSelected.equals(Constants.roundTrip)) {
                            linearLayoutReturn.setVisibility(View.VISIBLE);
                            radioButtonReturnTrip.setChecked(Boolean.TRUE);
                            editTextReturnDate.setText(ticket.returningDate);
                            editTextReturnTime.setText(ticket.returningTime);
                        }
                    }
                });

        alertDialogSource = builderSource.create();

        findViewById(R.id.buttonDelete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                intent = new Intent(DeleteActivity.this, MainActivity.class);
                intent.putExtra(Constants.LinkedListId_KEY, ticket.myId + "");
                startActivity(intent);
            }
        });

        editTextName.setKeyListener(null);
        editTextSource.setKeyListener(null);
        editTextDestination.setKeyListener(null);
        editTextDepartureDate.setKeyListener(null);
        editTextDepartureTime.setKeyListener(null);
        editTextReturnDate.setKeyListener(null);
        editTextReturnTime.setKeyListener(null);
        radioButtonOneWay.setKeyListener(null);
        radioButtonReturnTrip.setKeyListener(null);

        findViewById(R.id.buttonDeleteCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
