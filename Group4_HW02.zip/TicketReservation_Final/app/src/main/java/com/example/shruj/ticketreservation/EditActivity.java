/*
*
a. Assignment-2.
b. File Name- Group4_HW02.zip
c. Kaivalya Vyas, Shrujan Kotturi and Giang Dao
*
*
*
* */


package com.example.shruj.ticketreservation;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class EditActivity extends AppCompatActivity {

    CharSequence[] source = {"Albany, NY", "Atlanta, GA", "Boston, MA", "Charlotte, NC",
            "Chicago, IL", "Greenville, SC", "Houston, TX", "Las Vegas, NV", "Los Angeles, CA",
            "Miami, FL", "Myrtle Beach, SC", "New York, NY", "Portland, OR", "Raleigh, NC", "San Jose, CA", "Washington, DC"};
    CharSequence[] destination = {"Albany, NY", "Atlanta, GA", "Boston, MA", "Charlotte, NC",
            "Chicago, IL", "Greenville, SC", "Houston, TX", "Las Vegas, NV", "Los Angeles, CA",
            "Miami, FL", "Myrtle Beach, SC", "New York, NY", "Portland, OR", "Raleigh, NC", "San Jose, CA", "Washington, DC"};

    Intent intent;
    ArrayList<Ticket> tickets;
    ArrayList<Ticket> ticketArrayList = new ArrayList<>();
    Ticket ticket;



    Calendar calendar;
    Date dateTo = new Date();
    int todate = 0;
    int currdateRDate = 0;
    int currdateFDate  = 0;
    EditText editTextName, editTextSource, editTextDestination, editTextDepartureDate, editTextDepartureTime, editTextReturnDate, editTextReturnTime;

    LinearLayout linearLayoutReturn;
    RadioGroup radioGroup;
    RadioButton radioButtonOneWay, radioButtonReturnTrip;
    AlertDialog alertDialogSource, alertDialogDestination, alertDialogSelect;

    CharSequence[] names;
    String sourceLocation, destinationLocation, tripSelected = Constants.oneWayTrip;

    SimpleDateFormat simpleDateFormat;
    DatePickerDialog datePickerListenerDepartureDate, datePickerListenerReturningDate;
    TimePickerDialog timePickerDialogDepartureTime, timePickerDialogReturningDate;

    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
    Date returnDate  = null;
    Date DepDate = null;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);




        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(Boolean.TRUE);
        actionBar.setIcon(R.mipmap.ic_launcher);

        calendar = Calendar.getInstance();
        simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        editTextName = (EditText) findViewById(R.id.editTextName);
        editTextSource = (EditText) findViewById(R.id.editTextSource);
        editTextDestination = (EditText) findViewById(R.id.editTextDestination);
        editTextDepartureDate = (EditText) findViewById(R.id.editTextDepartureDate);
        editTextDepartureTime = (EditText) findViewById(R.id.editTextDepartureTime);
        editTextReturnDate = (EditText) findViewById(R.id.editTextReturnDate);
        editTextReturnTime = (EditText) findViewById(R.id.editTextReturnTime);
        radioButtonOneWay = (RadioButton) findViewById(R.id.radioButtonOneWay);
        radioButtonReturnTrip = (RadioButton) findViewById(R.id.radioButtonRoundTrip);
        linearLayoutReturn = (LinearLayout) findViewById(R.id.linearLayoutReturn);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroupTrip);

        RadioButton rButnoneWay = (RadioButton) findViewById(R.id.radioButtonOneWay);
        final RadioButton rbutnRound = (RadioButton) findViewById(R.id.radioButtonRoundTrip);

   final   Button  Finish = (Button)findViewById(R.id.buttonSave);
        Finish.setEnabled(false);

       // Finish.setOnClickListener(new Vi);


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = (RadioButton) findViewById(checkedId);
                tripSelected = radioButton.getText().toString();
                if (!tripSelected.equals(Constants.oneWayTrip)) {
                    linearLayoutReturn.setVisibility(View.VISIBLE);
                } else {
                    linearLayoutReturn.setVisibility(View.INVISIBLE);
                }
            }
        });


        intent = getIntent();
        if (intent.getExtras() != null) {
            tickets = (ArrayList<Ticket>) intent.getExtras().getSerializable(Constants.LinkedList_KEY);
        }
        findViewById(R.id.buttonSelectTicket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialogSelect.show();
                Finish.setEnabled(true);
            }
        });

        AlertDialog.Builder builderSelect = new AlertDialog.Builder(this);
        names = new CharSequence[tickets.size()];

        for (int i = 0; i < tickets.size(); i++) {
            names[i] = tickets.get(i).name;
        }


        builderSelect.setTitle(R.string.editTicketsTag)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        linearLayoutReturn.setVisibility(View.INVISIBLE);
                        ticket = tickets.get(which);
                        editTextName.setText(ticket.name);
                        sourceLocation = ticket.source;
                        destinationLocation = ticket.destination;
                        editTextSource.setText(ticket.source);
                        editTextDestination.setText(ticket.destination);
                        editTextDepartureDate.setText(ticket.departureDate);
                        editTextDepartureTime.setText(ticket.departureTime);
                        radioButtonOneWay.setChecked(Boolean.TRUE);
                        if (ticket.tripSelected.equals(Constants.roundTrip)) {
                            linearLayoutReturn.setVisibility(View.VISIBLE);
                            radioButtonReturnTrip.setChecked(Boolean.TRUE);
                            editTextReturnDate.setText(ticket.returningDate);
                            editTextReturnTime.setText(ticket.returningTime);
                        }
                    }
                });

        alertDialogSelect = builderSelect.create();

        AlertDialog.Builder builderSource = new AlertDialog.Builder(this);

        builderSource.setTitle(R.string.sourceTag)
                .setItems(source, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        sourceLocation = (String) source[which];
                        editTextSource.setText(sourceLocation);
                    }
                });

        alertDialogSource = builderSource.create();

        findViewById(R.id.editTextSource).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialogSource.show();
            }
        });

        AlertDialog.Builder builderDestination = new AlertDialog.Builder(this);

        builderDestination.setTitle(R.string.destinationTag)
                .setItems(destination, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                destinationLocation = (String) destination[which];
                                try {
                                    if (!sourceLocation.equals(destinationLocation)) {
                                        editTextDestination.setText(destinationLocation);
                                    } else {
                                        ToastMessages.DisplayToastMessages(getApplicationContext(), Constants.sourceDestinationError);
                                    }
                                } catch (NullPointerException ex) {
                                    ToastMessages.DisplayToastMessages(getApplicationContext(), Constants.sourceNullPointerError);
                                }
                            }
                        }

                );

        alertDialogDestination = builderDestination.create();

        findViewById(R.id.editTextDestination).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialogDestination.show();
            }
        });



        findViewById(R.id.buttonSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ticket.name = editTextName.getText().toString();
                ticket.source = editTextSource.getText().toString();
                ticket.destination = editTextDestination.getText().toString();
                ticket.departureTime = editTextDepartureTime.getText().toString();
                ticket.departureDate = editTextDepartureDate.getText().toString();
                ticket.tripSelected = tripSelected;
                ticket.returningDate = "";
                ticket.returningDate = "";
                if (tripSelected.equals(Constants.roundTrip)) {
                    ticket.returningTime = editTextReturnTime.getText().toString();
                    ticket.returningDate = editTextReturnDate.getText().toString();
                }

                tickets.set(ticket.myId, ticket);
                ticketArrayList.add(ticket);

              try {
                    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
                    Date datefrom = formatter.parse(editTextDepartureDate.getText().toString());
                    Log.d("CreateDemo", "" + datefrom.toString());
                    Date currDate = new Date();
                    currdateRDate = datefrom.compareTo(currDate);

                    if (tripSelected.equals(Constants.roundTrip)) {
                        dateTo = formatter.parse(editTextReturnDate.getText().toString());
                        Log.d("CreateDemo", "" + dateTo.toString());
                        todate = datefrom.compareTo(dateTo);


                        currdateFDate = dateTo.compareTo(currDate);
                    }


                    Log.d("CreateDemo2",""+currdateRDate);
                    Log.d("CreateDemo2",""+currdateFDate);

                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }





                if(editTextName.getText().toString().isEmpty())
                {
                    Toast.makeText(EditActivity.this, "Name Can not be Empty", Toast.LENGTH_LONG).show();
                    //   Button b = (Button)findViewById(R.id.buttonPrintSummary);
                    //  b.setEnabled(false);

                }

                else if (editTextDestination.getText().toString().isEmpty())
                {
                    Toast.makeText(EditActivity.this, "Destination Name Can not be Empty", Toast.LENGTH_LONG).show();
                }

                else if (editTextSource.getText().toString().isEmpty())
                {
                    Toast.makeText(EditActivity.this, "Source Name Can not be Empty", Toast.LENGTH_LONG).show();
                }

                else if (editTextDepartureDate.getText().toString().isEmpty())
                {
                    Toast.makeText(EditActivity.this, "Departure Date Can not be Empty", Toast.LENGTH_LONG).show();
                }

                else if (rbutnRound.isChecked() && editTextReturnDate.getText().toString().isEmpty()   )
                {
                    Toast.makeText(EditActivity.this, "Return Date Can not be Empty", Toast.LENGTH_LONG).show();
                }
                else if (editTextDepartureTime.getText().toString().isEmpty())
                {
                    Toast.makeText(EditActivity.this, "Departure Time Can not be Empty", Toast.LENGTH_LONG).show();

                }
                else if (rbutnRound.isChecked() && editTextReturnTime.getText().toString().isEmpty() )
                {
                    Toast.makeText(EditActivity.this, "Return Time Can not be Empty", Toast.LENGTH_LONG).show();

                }
               /* else if ( rbutnRound.isChecked() && DepDate.compareTo(returnDate) == -1    )
                    {
                        Toast.makeText(EditActivity.this, "Return Date Can not be less then Departure Date", Toast.LENGTH_LONG).show();
                    }*/

                else if (editTextDepartureTime.getText().toString().isEmpty())
                {
                    Toast.makeText(EditActivity.this, "Departure Time Can not be Empty", Toast.LENGTH_LONG).show();
                }
                else if (rbutnRound.isChecked() && editTextReturnTime.getText().toString().isEmpty()  )
                {
                    Toast.makeText(EditActivity.this, "Return Time Can not be Empty", Toast.LENGTH_LONG).show();
                }



                else if (rbutnRound.isChecked() && (todate == 1))
                {
                    Toast.makeText(EditActivity.this, "Return Date should not be less then departure date ", Toast.LENGTH_LONG).show();
                }

                else if (currdateRDate == -1 || currdateFDate == -1 )
                {
                    Toast.makeText(EditActivity.this, "Please Do not select past date", Toast.LENGTH_LONG).show();
                }



                else {

                    intent = new Intent(EditActivity.this, PrintTicketActivity.class);
                    intent.putExtra(Constants.LinkedList_KEY, ticketArrayList);
                    startActivity(intent);

                }





            }
        });

        datePickerListenerDepartureDate = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                editTextDepartureDate.setText(simpleDateFormat.format(newDate.getTime()));
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        findViewById(R.id.editTextDepartureDate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePickerListenerDepartureDate.setTitle(Constants.titleDepartureDate);
                datePickerListenerDepartureDate.show();
            }
        });

        datePickerListenerReturningDate = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                editTextReturnDate.setText(simpleDateFormat.format(newDate.getTime()));
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        findViewById(R.id.editTextReturnDate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePickerListenerReturningDate.setTitle(Constants.titleReturnDate);
                datePickerListenerReturningDate.show();
            }
        });

        timePickerDialogDepartureTime = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            Calendar calendar = Calendar.getInstance();

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);
                SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("hh:mm a");
                String time = simpleDateFormat1.format(calendar.getTime());
                editTextDepartureTime.setText(time);
            }
        }, Calendar.getInstance().get(Calendar.HOUR_OF_DAY), Calendar.getInstance().get(Calendar.MINUTE), Boolean.FALSE);

        timePickerDialogReturningDate = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            Calendar calendar = Calendar.getInstance();

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);
                SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("hh:mm a");
                String time = simpleDateFormat1.format(calendar.getTime());
                editTextReturnTime.setText(time);
            }
        }, Calendar.getInstance().get(Calendar.HOUR_OF_DAY), Calendar.getInstance().get(Calendar.MINUTE), Boolean.FALSE);

        findViewById(R.id.editTextDepartureTime).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timePickerDialogDepartureTime.setTitle(Constants.titleDepartureTime);
                timePickerDialogDepartureTime.show();
            }
        });

        findViewById(R.id.editTextReturnTime).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timePickerDialogReturningDate.setTitle(Constants.titleReturnTime);
                timePickerDialogReturningDate.show();
            }
        });

    }
}
