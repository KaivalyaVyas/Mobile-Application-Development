/*
*
a. Assignment-2.
b. File Name- Group4_HW02.zip
c. Kaivalya Vyas, Shrujan Kotturi and Giang Dao
*
*
*
* */

package com.example.shruj.ticketreservation;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {

    Intent intent;

    LinkedList<Ticket> linkedListTickets;
    ArrayList<Ticket> arrayListTickets = new ArrayList<>();
    static ArrayList<Ticket> ticketArrayList = new ArrayList<>();
    static int ticketArrayListId = 0;
    int ticketId = 0;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(Boolean.TRUE);
        actionBar.setIcon(R.mipmap.ic_launcher);

        intent = getIntent();

        if (intent.getExtras() != null) {
            if (intent.getExtras().getSerializable(Constants.LinkedList_KEY) != null) {
                arrayListTickets = (ArrayList<Ticket>) intent.getExtras().getSerializable(Constants.LinkedList_KEY);
                ticketArrayList.remove(arrayListTickets.get(0));
                ticketArrayList.add(arrayListTickets.get(0).myId, arrayListTickets.get(0));

            } else if (intent.getExtras().getString(Constants.LinkedListId_KEY) != null) {
                ticketId = Integer.parseInt(intent.getExtras().getString(Constants.LinkedListId_KEY));
                for (Ticket ticket : ticketArrayList) {
                    if (ticket.myId == ticketId) {
                        ticketArrayList.remove(ticketId);
                    }
                }
            }
        }


        findViewById(R.id.buttonCreateTicket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linkedListTickets = new LinkedList<>();
                linkedListTickets.add(new Ticket());
                intent = new Intent(MainActivity.this, CreateTicketActivity.class);
                intent.putExtra(Constants.LinkedList_KEY, linkedListTickets);
                startActivity(intent);
            }
        });

        String text = "<a href=\"tel:9999999999\">Customer Care: 999-999-9999</a>";

        ((TextView) findViewById(R.id.textViewCallCustomerCare)).setText(Html.fromHtml(text));
        (findViewById(R.id.textViewCallCustomerCare)).setClickable(Boolean.TRUE);

        (findViewById(R.id.textViewCallCustomerCare)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + "9999999999"));
                startActivity(intent);
            }
        });

        findViewById(R.id.buttonEditTicket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RemoveDuplicates();
                intent = new Intent(MainActivity.this, EditActivity.class);
                intent.putExtra(Constants.LinkedList_KEY, ticketArrayList);
                startActivity(intent);
            }
        });

        findViewById(R.id.buttonDeleteTicket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RemoveDuplicates();
                intent = new Intent(MainActivity.this, DeleteActivity.class);
                intent.putExtra(Constants.LinkedList_KEY, ticketArrayList);
                startActivity(intent);
            }
        });

        findViewById(R.id.buttonFinishTicket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.buttonViewTicket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RemoveDuplicates();
                intent = new Intent(MainActivity.this, ViewActivity.class);
                intent.putExtra(Constants.LinkedList_KEY, ticketArrayList);
                startActivity(intent);
            }
        });
    }

    private void RemoveDuplicates() {
        for (int i = 0; i < ticketArrayList.size() - 1; i++) {
            if (ticketArrayList.get(i).myId == ticketArrayList.get(i + 1).myId) {
                ticketArrayList.remove(i + 1);
            }
        }
    }
}
