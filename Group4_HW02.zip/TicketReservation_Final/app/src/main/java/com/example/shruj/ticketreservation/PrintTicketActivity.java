/*
*
a. Assignment-2.
b. File Name- Group4_HW02.zip
c. Kaivalya Vyas, Shrujan Kotturi and Giang Dao
*
*
*
* */

package com.example.shruj.ticketreservation;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class PrintTicketActivity extends AppCompatActivity {

    Intent intent;

    ArrayList<Ticket> tickets;

    TextView textViewTicketName, textViewTicketSource, textViewTicketDestination, textViewTicketDeparture, textViewTicketReturn;
    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print_ticket);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(Boolean.TRUE);
        actionBar.setIcon(R.mipmap.ic_launcher);

        textViewTicketDeparture = (TextView) findViewById(R.id.textViewTicketDeparture);
        textViewTicketDestination = (TextView) findViewById(R.id.textViewTicketDestination);
        textViewTicketName = (TextView) findViewById(R.id.textViewTicketName);
        textViewTicketReturn = (TextView) findViewById(R.id.textViewTicketReturn);
        textViewTicketSource = (TextView) findViewById(R.id.textViewTicketSource);

        linearLayout = (LinearLayout) findViewById(R.id.linearLayoutReturn);

        intent = getIntent();
        if (intent.getExtras() != null) {
            tickets = (ArrayList<Ticket>) intent.getExtras().getSerializable(Constants.LinkedList_KEY);


            for (Ticket ticket : tickets) {
                textViewTicketName.setText(ticket.name);
                textViewTicketDeparture.setText(ticket.departureDate + " " + ticket.departureTime);
                textViewTicketSource.setText(ticket.source);
                textViewTicketDestination.setText(ticket.destination);

                if (ticket.tripSelected.equals(Constants.roundTrip)) {
                    linearLayout.setVisibility(View.VISIBLE);
                    textViewTicketReturn.setText(ticket.returningDate + " " + ticket.returningTime);
                }

            }
            findViewById(R.id.buttonFinish).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    intent = new Intent(PrintTicketActivity.this, MainActivity.class); //debug purpose
                    intent.putExtra(Constants.LinkedList_KEY, tickets);
                    startActivity(intent);
                }
            });
        }

    }
}
