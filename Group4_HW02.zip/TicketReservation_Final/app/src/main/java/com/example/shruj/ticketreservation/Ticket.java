/*
*
a. Assignment-2.
b. File Name- Group4_HW02.zip
c. Kaivalya Vyas, Shrujan Kotturi and Giang Dao
*
*
*
* */

package com.example.shruj.ticketreservation;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.Nullable;

import java.io.Serializable;
import java.sql.Time;
import java.util.Date;

/**
 * Created by shruj on 02/05/2016.
 */
public class Ticket implements Serializable {
    private static int ID = 0;
    int myId = 0;
    String name;
    String source;

    public Ticket() {
        this.myId = ID;
        ID++;
    }

    String destination;
    String tripSelected;
    String departureDate;
    String departureTime;
    @Nullable
    String returningDate;
    @Nullable
    String returningTime;


}


