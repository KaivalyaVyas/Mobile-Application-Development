/*
*
a. Assignment-2.
b. File Name- Group4_HW02.zip
c. Kaivalya Vyas, Shrujan Kotturi and Giang Dao
*
*
*
* */

package com.example.shruj.ticketreservation;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by shruj on 02/05/2016.
 */
public class ToastMessages {
    public static void DisplayToastMessages(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

}
