/*
*
a. Assignment-2.
b. File Name- Group4_HW02.zip
c. Kaivalya Vyas, Shrujan Kotturi and Giang Dao
*
*
*
* */


package com.example.shruj.ticketreservation;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;

import java.util.ArrayList;

public class ViewActivity extends AppCompatActivity {


    Intent intent;
    ArrayList<Ticket> tickets;
    Ticket currentTicket;
    int currentArrayListObject = 0, size = 0;
    EditText name, source, destination, ViewDepartureDate, ViewReturnDate, ViewDepartureTime, ViewReturnTime;
    ImageButton next, previous, last, first;
    Button finish;
    RadioButton rbOneWay, radioButtonReturnTrip;
    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(Boolean.TRUE);
        actionBar.setIcon(R.mipmap.ic_launcher);

        name = (EditText) findViewById(R.id.editTextViewName);
        source = (EditText) findViewById(R.id.editTextViewSource);
        destination = (EditText) findViewById(R.id.editTextViewDestination);

        linearLayout = (LinearLayout) findViewById(R.id.linearLayoutViewReturn);

        ViewDepartureDate = (EditText) findViewById(R.id.editTextViewDepartureDate);
        ViewDepartureTime = (EditText) findViewById(R.id.editTextViewDepartureTime);
        ViewReturnDate = (EditText) findViewById(R.id.editTextViewReturnDate);
        ViewReturnTime = (EditText) findViewById(R.id.editTextViewReturnTime);

        rbOneWay = (RadioButton) findViewById(R.id.radioButtonViewOneWay);
        radioButtonReturnTrip = (RadioButton) findViewById(R.id.radioButtonViewRoundTrip);

        next = (ImageButton) findViewById(R.id.Next);
        previous = (ImageButton) findViewById(R.id.Previous);
        last = (ImageButton) findViewById(R.id.Last);
        first = (ImageButton) findViewById(R.id.first);
        finish = (Button) findViewById(R.id.Finish);

        name.setEnabled(false);
        source.setEnabled(false);
        destination.setEnabled(false);
        ViewDepartureDate.setEnabled(false);
        ViewDepartureTime.setEnabled(false);
        ViewReturnDate.setEnabled(false);
        ViewReturnTime.setEnabled(false);
        rbOneWay.setEnabled(false);
        radioButtonReturnTrip.setEnabled(false);

        intent = getIntent();

        if (intent.getExtras() != null) {
            tickets = (ArrayList<Ticket>) intent.getExtras().getSerializable(Constants.LinkedList_KEY);
            size = tickets.size();

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentArrayListObject++;
                    showTicket(currentArrayListObject);
                }
            });

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentArrayListObject--;
                    showTicket(currentArrayListObject);
                }
            });

            first.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentArrayListObject = 0;
                    showTicket(currentArrayListObject);

                }
            });

            last.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentArrayListObject = size - 1;
                    showTicket(currentArrayListObject);
                }
            });

            finish.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });

        }


    }

    private void showTicket(int index) {

        if (!tickets.isEmpty()) {
            if ((index + 1) > tickets.size()) {
                currentArrayListObject = 0;
            } else if (index < 0) {
                currentArrayListObject = (tickets.size() - 1);
            }
            linearLayout.setVisibility(View.INVISIBLE);
            currentTicket = tickets.get(currentArrayListObject);
            name.setText(currentTicket.name);
            source.setText(currentTicket.source);
            destination.setText(currentTicket.destination);
            ViewDepartureDate.setText(currentTicket.departureDate);
            ViewDepartureTime.setText(currentTicket.departureTime);
            rbOneWay.setChecked(Boolean.TRUE);
            if (currentTicket.tripSelected.equals(Constants.roundTrip)) {
                linearLayout.setVisibility(View.VISIBLE);
                ViewReturnDate.setText(currentTicket.returningDate);
                ViewReturnTime.setText(currentTicket.returningTime);
                radioButtonReturnTrip.setChecked(Boolean.TRUE);
            }
        } else {
            ToastMessages.DisplayToastMessages(getApplicationContext(), Constants.viewArrayListOutOfBounds);
        }
    }


}
