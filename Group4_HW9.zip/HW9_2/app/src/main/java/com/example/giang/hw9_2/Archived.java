package com.example.giang.hw9_2;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Archived.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class Archived extends Fragment {

    private OnFragmentInteractionListener mListener;

    public Archived() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_archived, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
        void toMessageViewF(User u, User otherUser);
        void toContact(User u);
        void toConversation(User u);
        void toSettings(User u, String UID);

    }

    User u;
    static Archived fragment = new Archived();
    public static Archived newInstance(User u) {

        Bundle args = new Bundle();
        args.putSerializable("YOU", u);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        u = (User) fragment.getArguments().getSerializable("YOU");
    }

    Firebase ref, convRoot, userRoot, msgRoot;
    Activity activity;
    ListView lv;
    ArrayList<Conversation> conversationArrayList;
    ArrayList<User> userArrayList;
    ArrayList<Message> messageArrayList;
    ArrayList<StayInTouchObject> stayInTouchObjectArrayList;
    String picture, phone, otherUser, message_read;
    CommonAdapter commonAdapter;
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Firebase.setAndroidContext(getActivity());
        ref = new Firebase("https://group4-hw9.firebaseio.com/");
        userRoot = new Firebase("https://group4-hw9.firebaseio.com/users/");
        msgRoot = new Firebase("https://group4-hw9.firebaseio.com/Messages/");
        convRoot = new Firebase("https://group4-hw9.firebaseio.com/Conversations/");

        activity = getActivity();
        lv = (ListView) getActivity().findViewById(R.id.listViewArchived);

        convRoot.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                conversationArrayList = new ArrayList<Conversation>();
                for (DataSnapshot post : dataSnapshot.getChildren()) {
                    Conversation conv = post.getValue(Conversation.class);

//                    if (conv.getParticipant2().equals(u.getEmail()) || conv.getParticipant1().equals(u.getEmail())) {
//                        if (!conv.getIsArchived_by_participant1().equals("true") || !conv.getIsArchived_by_participant2().equals(u.getEmail()))
//                        conversationArrayList.add(conv);
//                    }
                    if (conv.getParticipant1().equals(u.getEmail()) && conv.getIsArchived_by_participant1().equals("true"))
                        conversationArrayList.add(conv);
                    else if(conv.getParticipant2().equals(u.getEmail()) && conv.getIsArchived_by_participant2().equals("true"))
                        conversationArrayList.add(conv);
                }

                userRoot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot2) {
                        userArrayList = new ArrayList<User>();
                        for (DataSnapshot post2 : dataSnapshot2.getChildren()) {
                            User checkUser = post2.getValue(User.class);
                            //NOT the login one
                            if (!checkUser.getEmail().equals(u.getEmail())) {
                                for (Conversation conv : conversationArrayList) {
                                    if (checkUser.getEmail().equals(conv.getParticipant1())
                                            || checkUser.getEmail().equals(conv.getParticipant2())) {
                                        userArrayList.add(checkUser);
                                        break;
                                    }
                                }
                            }
                        }

                        msgRoot.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot3) {
                                messageArrayList = new ArrayList<Message>();
                                for (DataSnapshot postSnapshot2 : dataSnapshot3.getChildren()) {
                                    Message msg = postSnapshot2.getValue(Message.class);
                                    //Filter Message
                                    if (msg.getReceiver().equals(u.getFullname()) || msg.getSender().equals(u.getFullname()))
                                        messageArrayList.add(msg);
                                }

                                stayInTouchObjectArrayList = new ArrayList<>();
                                stayInTouchObjectArrayList.clear();
                                boolean needToRemove = false;
                                for (User user : userArrayList) {
                                    picture = user.getPicture();
                                    phone = user.getPhone();
                                    otherUser = user.getFullname();
                                    if (!messageArrayList.isEmpty()) {

                                        for (int i = 0; i < messageArrayList.size(); i++) {
                                            Message message = messageArrayList.get(i);
                                            if (message.getSender().equals(u.getFullname()) && message.getReceiver().equals(user.getFullname())
                                                    || message.getSender().equals(user.getFullname()) && message.getReceiver().equals(u.getFullname())) {
                                                if (message.getReceiver().equals(u.getFullname()))
                                                    message_read = message.getMessage_read();
                                                else
                                                    message_read = "true";
                                            } else {
                                                message_read = "true";
                                            }
                                        }
                                    } else {
                                        message_read = "true";
                                    }
                                    //Set up object for ListView Adapter
                                    StayInTouchObject stayInTouchObject = new StayInTouchObject(picture, otherUser, message_read, phone);
                                    stayInTouchObjectArrayList.add(stayInTouchObject);
                                }
                                commonAdapter = new CommonAdapter(activity, R.layout.common_listview, stayInTouchObjectArrayList);

                                lv.setAdapter(commonAdapter);
                                commonAdapter.setNotifyOnChange(true);

                                //ListView on Item Click
                                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                                        msgRoot.addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot3) {
                                                for (DataSnapshot postSnapshot : dataSnapshot3.getChildren()) {
                                                    Message msg = postSnapshot.getValue(Message.class);
                                                    if (msg.getSender().equals(userArrayList.get(position).getFullname())
                                                            && msg.getReceiver().equals(u.getFullname()))
                                                        msgRoot.child(postSnapshot.getKey())
                                                                .child("message_read").setValue("true");
                                                }
                                            }

                                            @Override
                                            public void onCancelled(FirebaseError firebaseError) {
                                                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        });
                                        mListener.toMessageViewF(u, userArrayList.get(position));
                                    }
                                });
                            }

                            @Override
                            public void onCancelled(FirebaseError firebaseError) {
                                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        });
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {
                        Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
