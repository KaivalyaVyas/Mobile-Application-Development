package com.example.giang.hw9_2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Giang on 4/27/2016.
 */
public class CommonAdapter extends ArrayAdapter<StayInTouchObject> {
    List<StayInTouchObject> mData;
    Context mContext;
    int mResource;

    public CommonAdapter(Context context, int resource, List<StayInTouchObject> objects) {
        super(context, resource, objects);
        mData = objects;
        mContext = context;
        mResource = resource;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null){
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);

            holder = new ViewHolder();

            holder.tv = (TextView) convertView.findViewById(R.id.textViewName);
            holder.imgPhone = (ImageView) convertView.findViewById(R.id.imageViewCall);
            holder.imgRedDot = (ImageView) convertView.findViewById(R.id.imageViewRedDot);
            holder.imgProfile = (ImageView) convertView.findViewById(R.id.imageViewProfile);
            convertView.setTag(holder);
        }

        final StayInTouchObject stayInTouchObject = mData.get(position);
        holder = (ViewHolder) convertView.getTag();
        TextView tvName = holder.tv;
        ImageView imgPhone = holder.imgPhone;
        ImageView imgRedDot = holder.imgRedDot;
        ImageView imgProfile = holder.imgProfile;

        tvName.setText(stayInTouchObject.getName());
        //Set image profile
        byte[] decodedString = Base64.decode(stayInTouchObject.getPicture(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imgProfile.setImageBitmap(decodedByte);

        if (stayInTouchObject.getMessage_read().equals("false")){
            imgRedDot.setVisibility(View.VISIBLE);
        } else{
            imgRedDot.setVisibility(View.INVISIBLE);
        }

        imgPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+stayInTouchObject.getCallPhone()));
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }

    static class ViewHolder{
        ImageView imgProfile, imgRedDot, imgPhone;
        TextView tv;
    }
}
