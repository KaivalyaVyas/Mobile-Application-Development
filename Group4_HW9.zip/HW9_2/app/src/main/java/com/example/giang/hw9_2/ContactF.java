package com.example.giang.hw9_2;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ContactF.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class ContactF extends Fragment {

    private OnFragmentInteractionListener mListener;

    public ContactF() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_contact, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);

        void toMessageViewF(User u, User otherUser);
        void toViewContactF(User otherUser);
        void toSettings(User u, String UID);
        void toConversation(User u);
        void toArchived(User u);
    }

    User u;
    static ContactF contactF;

    public static ContactF newInstance(User u) {

        Bundle args = new Bundle();
        args.putSerializable("YOU", u);
        contactF = new ContactF();
        contactF.setArguments(args);
        return contactF;
    }

    Firebase ref, userRoot, msgRoot;
    ArrayList<User> userArrayList;
    ArrayList<Message> messageArrayList;
    ArrayList<StayInTouchObject> stayInTouchObjectArrayList;
    String picture, phone, otherUser, message_read;
    ListView lv;
    CommonAdapter commonAdapter;
    Activity activity;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        u = (User) contactF.getArguments().getSerializable("YOU");
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Firebase.setAndroidContext(getActivity());
        ref = new Firebase("https://group4-hw9.firebaseio.com/");
        lv = (ListView) getActivity().findViewById(R.id.listViewContactF);

        activity = getActivity();
        userRoot = ref.child("users");
        userRoot.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                userArrayList = new ArrayList<User>();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    User checkUser = postSnapshot.getValue(User.class);
                    if (!checkUser.getEmail().equals(u.getEmail()))
                        userArrayList.add(checkUser);
                }
                Log.d("demo", userArrayList.toString());

                msgRoot = ref.child("Messages");
                msgRoot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot2) {
                        messageArrayList = new ArrayList<Message>();
                        for (DataSnapshot postSnapshot2 : dataSnapshot2.getChildren()) {
                            Message msg = postSnapshot2.getValue(Message.class);
                            //Filter Message
                            if (msg.getReceiver().equals(u.getFullname()) || msg.getSender().equals(u.getFullname()))
                                messageArrayList.add(msg);
                        }

                        Log.d("demo", "Message Order: "+messageArrayList.toString());
                        stayInTouchObjectArrayList = new ArrayList<>();
                        stayInTouchObjectArrayList.clear();
                        for (User user : userArrayList) {
                            picture = user.getPicture();
                            phone = user.getPhone();
                            otherUser = user.getFullname();
                            if (!messageArrayList.isEmpty()) {

                                for (int i =0; i<messageArrayList.size(); i++){
                                    Message message = messageArrayList.get(i);
                                    if (message.getSender().equals(u.getFullname()) && message.getReceiver().equals(user.getFullname())
                                            || message.getSender().equals(user.getFullname()) && message.getReceiver().equals(u.getFullname())) {
                                        if (message.getReceiver().equals(u.getFullname()))
                                            message_read = message.getMessage_read();
                                        else
                                            message_read = "true";
                                    } else{
                                        message_read = "true";
                                    }
                                }
                            } else {
                                message_read = "true";
                            }
                            //Set up object for ListView Adapter
                            StayInTouchObject stayInTouchObject = new StayInTouchObject(picture, otherUser, message_read, phone);
                            stayInTouchObjectArrayList.add(stayInTouchObject);
                        }
                        Log.d("demo", "stay In Touch Obj: " + stayInTouchObjectArrayList.toString());
                        //Set up ListView
//                        Log.d("demoContext", getActivity().toString());
//                        Log.d("demoResource", ""+R.layout.common_listview);
//                        Log.d("demoObj", stayInTouchObjectArrayList.toString());
                        commonAdapter = new CommonAdapter(activity, R.layout.common_listview, stayInTouchObjectArrayList);

                        lv.setAdapter(commonAdapter);
                        commonAdapter.setNotifyOnChange(true);

                        //ListView on Item Click
                        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                                msgRoot.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot3) {
                                        for (DataSnapshot postSnapshot : dataSnapshot3.getChildren()) {
                                            Message msg = postSnapshot.getValue(Message.class);
                                            if (msg.getSender().equals(userArrayList.get(position).getFullname())
                                                    && msg.getReceiver().equals(u.getFullname()))
                                                msgRoot.child(postSnapshot.getKey())
                                                        .child("message_read").setValue("true");
                                        }
                                    }

                                    @Override
                                    public void onCancelled(FirebaseError firebaseError) {
                                        Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                });
                                mListener.toMessageViewF(u, userArrayList.get(position));
                            }
                        });

                        //ListView on Long Click
                        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                            @Override
                            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                                mListener.toViewContactF(userArrayList.get(position));
                                return true;
                            }
                        });
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {
                        Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
