package com.example.giang.hw9_2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Conversations.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class Conversations extends Fragment {

    private OnFragmentInteractionListener mListener;

    public Conversations() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_conversations, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);

        void toMessageViewF(User u, User otherUser);
        void addConversation(User u);
        void toContact(User u);
        void toSettings(User u, String UID);
        void toArchived(User u);

    }

    static Conversations conversations = new Conversations();
    User u;

    public static Conversations newInstance(User u) {

        Bundle args = new Bundle();

        args.putSerializable("YOU", u);
        conversations.setArguments(args);
        return conversations;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        u = (User) conversations.getArguments().getSerializable("YOU");
    }

    Firebase ref, userRoot, msgRoot, convRoot;
    Activity activity;
    ListView lv;
    ArrayList<Conversation> conversationArrayList;
    ArrayList<User> userArrayList;
    ArrayList<Message> messageArrayList;
    ArrayList<StayInTouchObject> stayInTouchObjectArrayList;
    String picture, phone, otherUser, message_read;
    CommonAdapter commonAdapter;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Firebase.setAndroidContext(getActivity());
        ref = new Firebase("https://group4-hw9.firebaseio.com/");
        userRoot = new Firebase("https://group4-hw9.firebaseio.com/users/");
        msgRoot = new Firebase("https://group4-hw9.firebaseio.com/Messages/");
        convRoot = new Firebase("https://group4-hw9.firebaseio.com/Conversations/");

        activity = getActivity();
        lv = (ListView) getActivity().findViewById(R.id.listViewConversations);

        convRoot.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                conversationArrayList = new ArrayList<Conversation>();
                for (DataSnapshot post : dataSnapshot.getChildren()) {
                    Conversation conv = post.getValue(Conversation.class);

//                    if (conv.getParticipant2().equals(u.getEmail()) || conv.getParticipant1().equals(u.getEmail())) {
//                        if (!conv.getIsArchived_by_participant1().equals("true") || !conv.getIsArchived_by_participant2().equals(u.getEmail()))
//                        conversationArrayList.add(conv);
//                    }
                    if (conv.getParticipant1().equals(u.getEmail()) && !conv.getIsArchived_by_participant1().equals("true"))
                        conversationArrayList.add(conv);
                    else if(conv.getParticipant2().equals(u.getEmail()) && !conv.getIsArchived_by_participant2().equals("true"))
                        conversationArrayList.add(conv);
                }

                userRoot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot2) {
                        userArrayList = new ArrayList<User>();
                        for (DataSnapshot post2 : dataSnapshot2.getChildren()) {
                            User checkUser = post2.getValue(User.class);
                            //NOT the login one
                            if (!checkUser.getEmail().equals(u.getEmail())) {
                                for (Conversation conv : conversationArrayList) {
                                    if (checkUser.getEmail().equals(conv.getParticipant1())
                                            || checkUser.getEmail().equals(conv.getParticipant2())) {
                                        userArrayList.add(checkUser);
                                        break;
                                    }
                                }
                            }
                        }

                        msgRoot.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot3) {
                                messageArrayList = new ArrayList<Message>();
                                for (DataSnapshot postSnapshot2 : dataSnapshot3.getChildren()) {
                                    Message msg = postSnapshot2.getValue(Message.class);
                                    //Filter Message
                                    if (msg.getReceiver().equals(u.getFullname()) || msg.getSender().equals(u.getFullname()))
                                        messageArrayList.add(msg);
                                }

                                stayInTouchObjectArrayList = new ArrayList<>();
                                stayInTouchObjectArrayList.clear();
                                boolean needToRemove = false;
                                for (User user : userArrayList) {
                                    picture = user.getPicture();
                                    phone = user.getPhone();
                                    otherUser = user.getFullname();
                                    if (!messageArrayList.isEmpty()) {

                                        for (int i = 0; i < messageArrayList.size(); i++) {
                                            Message message = messageArrayList.get(i);
                                            if (message.getSender().equals(u.getFullname()) && message.getReceiver().equals(user.getFullname())
                                                    || message.getSender().equals(user.getFullname()) && message.getReceiver().equals(u.getFullname())) {
                                                if (message.getReceiver().equals(u.getFullname()))
                                                    message_read = message.getMessage_read();
                                                else
                                                    message_read = "true";
                                            } else {
                                                message_read = "true";
                                            }
                                        }
                                    } else {
                                        message_read = "true";
                                    }
                                    //Set up object for ListView Adapter
                                    StayInTouchObject stayInTouchObject = new StayInTouchObject(picture, otherUser, message_read, phone);
                                    stayInTouchObjectArrayList.add(stayInTouchObject);
                                }
                                commonAdapter = new CommonAdapter(activity, R.layout.common_listview, stayInTouchObjectArrayList);

                                lv.setAdapter(commonAdapter);
                                commonAdapter.setNotifyOnChange(true);

                                //ListView on Item Click
                                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                                        msgRoot.addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot3) {
                                                for (DataSnapshot postSnapshot : dataSnapshot3.getChildren()) {
                                                    Message msg = postSnapshot.getValue(Message.class);
                                                    if (msg.getSender().equals(userArrayList.get(position).getFullname())
                                                            && msg.getReceiver().equals(u.getFullname()))
                                                        msgRoot.child(postSnapshot.getKey())
                                                                .child("message_read").setValue("true");
                                                }
                                            }

                                            @Override
                                            public void onCancelled(FirebaseError firebaseError) {
                                                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        });
                                        mListener.toMessageViewF(u, userArrayList.get(position));
                                    }
                                });

                                //ListView on Item Long Click
                                lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                                    @Override
                                    public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                                        new AlertDialog.Builder(activity)
                                                .setPositiveButton("Archive", new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        convRoot.addValueEventListener(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(DataSnapshot dataSnapshot12) {
                                                                for (DataSnapshot post12: dataSnapshot12.getChildren()){
                                                                    Conversation conv = post12.getValue(Conversation.class);
                                                                    if (conv.getParticipant1().equals(u.getEmail()) && conv.getParticipant2().equals(userArrayList.get(position).getEmail())){
                                                                        convRoot.child(post12.getKey()).child("isArchived_by_participant1").setValue("true");
                                                                    }else if(conv.getParticipant2().equals(u.getEmail()) && conv.getParticipant1().equals(userArrayList.get(position).getEmail())){
                                                                        convRoot.child(post12.getKey()).child("isArchived_by_participant2").setValue("true");
                                                                    }
                                                                }
                                                            }

                                                            @Override
                                                            public void onCancelled(FirebaseError firebaseError) {
                                                                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                                                            }
                                                        });
                                                    }
                                                })
                                                .setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        convRoot.addValueEventListener(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(DataSnapshot dataSnapshot123) {
                                                                for (DataSnapshot post123 : dataSnapshot123.getChildren()) {
                                                                    Conversation conv = post123.getValue(Conversation.class);
                                                                    if (conv.getParticipant1().equals(u.getEmail()) && conv.getParticipant2().equals(userArrayList.get(position).getEmail())){
                                                                        if (conv.getDeletedBy().equals(userArrayList.get(position).getEmail())){
                                                                            convRoot.child(post123.getKey()).removeValue();
                                                                        }else{
                                                                            convRoot.child(post123.getKey()).child("deletedBy").setValue(u.getEmail());
                                                                        }
                                                                    }else if(conv.getParticipant2().equals(u.getEmail()) && conv.getParticipant1().equals(userArrayList.get(position).getEmail())){
                                                                        if (conv.getDeletedBy().equals(userArrayList.get(position).getEmail())){
                                                                            convRoot.child(post123.getKey()).removeValue();
                                                                        }else{
                                                                            convRoot.child(post123.getKey()).child("deletedBy").setValue(u.getEmail());
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            @Override
                                                            public void onCancelled(FirebaseError firebaseError) {
                                                                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                                                            }
                                                        });
                                                    }
                                                })
                                                .show();
                                        return true;
                                    }
                                });
                            }

                            @Override
                            public void onCancelled(FirebaseError firebaseError) {
                                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        });
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {
                        Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
