package com.example.giang.hw9_2;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.client.AuthData;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

public class MainActivity extends AppCompatActivity implements Conversations.OnFragmentInteractionListener,
        ViewMessageF.OnFragmentInteractionListener, ViewContactF.OnFragmentInteractionListener,
        ContactF.OnFragmentInteractionListener, Login.OnFragmentInteractionListener,
        SignUp.OnFragmentInteractionListener, Settings.OnFragmentInteractionListener, Archived.OnFragmentInteractionListener {

    Firebase ref;
    TextView textView_ViewContactName_menu;
    ImageView imageView_ViewContactdp_menu;

    private DrawerLayout mDrawer;
    ActionBar actionBar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView nvDrawer;
    String UID;
    User u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Firebase.setAndroidContext(this);

        mDrawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, mDrawer, R.string.openDrawer, R.string.closeDrawer);
        mDrawer.setDrawerListener(actionBarDrawerToggle);
        actionBar = getSupportActionBar();
        nvDrawer = (NavigationView) findViewById(R.id.nvView);
        setupDrawerContent(nvDrawer);
        View headerView = LayoutInflater.from(this).inflate(R.layout.nav_header, nvDrawer, false);
        nvDrawer.addHeaderView(headerView);
        textView_ViewContactName_menu = (TextView) headerView.findViewById(R.id.textViewNDName);
        imageView_ViewContactdp_menu = (ImageView) headerView.findViewById(R.id.imageViewNDName);

        ref = new Firebase("https://group4-hw9.firebaseio.com/");

        ref.addAuthStateListener(new Firebase.AuthStateListener() {
            @Override
            public void onAuthStateChanged(final AuthData authData) {
                if (authData != null) {
                    ref.child("users").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            for (DataSnapshot post : dataSnapshot.getChildren()) {
                                if (post.getKey().equals(authData.getUid())) {
                                    u = post.getValue(User.class);
//                                    Log.d("demo", u.toString());
                                    textView_ViewContactName_menu.setText(u.getFullname());
                                    byte[] decodedString = Base64.decode(u.getPicture(), Base64.DEFAULT);
                                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                    imageView_ViewContactdp_menu.setImageBitmap(decodedByte);
                                    //Go to Conversation
                                    addConversation(u);
                                }
                            }
                        }

                        @Override
                        public void onCancelled(FirebaseError firebaseError) {

                        }
                    });
                } else {
                    textView_ViewContactName_menu.setText("Please Login");
                    imageView_ViewContactdp_menu.setImageResource(R.drawable.defaimg);
                    //Go to Login
                    addLogin();
                }
            }
        });
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        actionBarDrawerToggle.syncState();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            if (mDrawer.isDrawerOpen(nvDrawer))
                mDrawer.closeDrawer(nvDrawer);
            else
                mDrawer.openDrawer(nvDrawer);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupDrawerContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        selectDrawerItem(menuItem);
                        return true;
                    }
                });
    }

    public void selectDrawerItem(MenuItem menuItem) {

        // Navigate to respective fragments based on nav item clicked
        switch (menuItem.getItemId()) {
            //Contact
            case R.id.nav_contact_fragment:
                Log.d("demo", "Click");
                ref = new Firebase("https://group4-hw9.firebaseio.com/");
                ref.addAuthStateListener(new Firebase.AuthStateListener() {
                    @Override
                    public void onAuthStateChanged(final AuthData authData) {
                        ref = ref.child("users");
                        ref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot post : dataSnapshot.getChildren()) {
                                    if (post.getKey().equals(authData.getUid())) {
                                        u = post.getValue(User.class);
                                        Log.d("demo", u.toString());
                                        toContact(u);
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(FirebaseError firebaseError) {

                            }
                        });
                    }
                });
                break;
            //Conversation
            case R.id.nav_conversation_fragment:
                ref = new Firebase("https://group4-hw9.firebaseio.com/");

                ref.addAuthStateListener(new Firebase.AuthStateListener() {
                    @Override
                    public void onAuthStateChanged(final AuthData authData) {
                        ref = ref.child("users");
                        ref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot post : dataSnapshot.getChildren()) {
                                    if (post.getKey().equals(authData.getUid())) {
                                        u = post.getValue(User.class);

                                        UID = authData.getUid();
                                        Log.d("demo", u.toString());
                                        toConversation(u);
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(FirebaseError firebaseError) {

                            }
                        });
                    }
                });
                break;
            //Archived
            case R.id.nav_archive_fragment:
                ref = new Firebase("https://group4-hw9.firebaseio.com/");

                ref.addAuthStateListener(new Firebase.AuthStateListener() {
                    @Override
                    public void onAuthStateChanged(final AuthData authData) {
                        ref = ref.child("users");
                        ref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot post : dataSnapshot.getChildren()) {
                                    if (post.getKey().equals(authData.getUid())) {
                                        u = post.getValue(User.class);
                                        toArchived(u);
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(FirebaseError firebaseError) {

                            }
                        });
                    }
                });
                break;
            //Settings
            case R.id.nav_setting_fragment:
                ref = new Firebase("https://group4-hw9.firebaseio.com/");
                Log.d("demo", "CLICK");
                ref.addAuthStateListener(new Firebase.AuthStateListener() {
                    @Override
                    public void onAuthStateChanged(final AuthData authData) {
                        if (authData!= null){
                        ref = ref.child("users");
                        ref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot post : dataSnapshot.getChildren()) {
                                    if (post.getKey().equals(authData.getUid())) {
                                        u = post.getValue(User.class);
                                        UID = authData.getUid();
                                        Log.d("demo", UID);
                                        Log.d("demo", u.toString());
                                        toSettings(u, UID);
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(FirebaseError firebaseError) {

                            }
                        });
                        }else{
                            toLogin();
                        }
                    }
                });
                break;
            case R.id.nav_logout_fragment:
                ref = new Firebase("https://group4-hw9.firebaseio.com/");
                ref.unauth();
                toLogin();
                break;
            case R.id.nav_exit_fragment:
                finish();
                break;
            default:
                break;
        }
        menuItem.setChecked(true);
        mDrawer.closeDrawers();
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void toMessageViewF(User u, User otherUser) {
        ViewMessageF viewMessageF = ViewMessageF.newInstance(u, otherUser);
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new ViewMessageF(), "toViewMessageF")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void addConversation(User u) {
        Conversations conversation = Conversations.newInstance(u);
        getFragmentManager().beginTransaction()
                .add(R.id.container, new Conversations(), "addConversation")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void toViewContactF(User otherUser) {
        ViewContactF viewContactF = ViewContactF.newInstance(otherUser);
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new ViewContactF(), "toViewContactF")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void toLogin() {
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new Login(), "toLogin")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void addLogin() {
        getFragmentManager().beginTransaction()
                .add(R.id.container, new Login(), "addLogin")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void toSignUp() {
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new SignUp(), "toSignUp")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void toConversation(User u) {
        Conversations conversations = Conversations.newInstance(u);
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new Conversations(), "toConversations")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void toContact(User u) {
        ContactF contactF = ContactF.newInstance(u);
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new ContactF(), "toContact")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void toSettings(User u, String UID) {
        Settings settings = Settings.newInstance(u, UID);
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new Settings(), "toSettings")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void toArchived(User u) {
        Archived archived = Archived.newInstance(u);
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new Archived(), "toArchived")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0)
            getFragmentManager().popBackStack();
        else
            super.onBackPressed();
    }
}
