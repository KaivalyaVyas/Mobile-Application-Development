package com.example.giang.hw9_2;

/**
 * Created by gdao_000 on 4/16/2016.
 */
public class MessageUserCombine {
    String sender, message_text, timeStamp, isSender;

    @Override
    public String toString() {
        return "MessageUserCombine{" +
                "sender='" + sender + '\'' +
                ", message_text='" + message_text + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", isSender='" + isSender + '\'' +
                '}';
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getMessage_text() {
        return message_text;
    }

    public void setMessage_text(String message_text) {
        this.message_text = message_text;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getIsSender() {
        return isSender;
    }

    public void setIsSender(String isSender) {
        this.isSender = isSender;
    }

    public MessageUserCombine() {

    }

    public MessageUserCombine(String sender, String message_text, String timeStamp, String isSender) {

        this.sender = sender;
        this.message_text = message_text;
        this.timeStamp = timeStamp;
        this.isSender = isSender;
    }
}
