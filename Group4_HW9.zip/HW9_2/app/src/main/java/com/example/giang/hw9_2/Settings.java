package com.example.giang.hw9_2;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Settings.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class Settings extends Fragment {

    private OnFragmentInteractionListener mListener;

    public Settings() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
        void toContact(User u);
        void toConversation(User u);
        void toArchived(User u);
    }

    String UID;
    User u;
    static Settings fragment = new Settings();

    public static Settings newInstance(User u, String UID) {
        Bundle args = new Bundle();
        args.putSerializable("YOU", u);
        args.putString("UID", UID);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        u = (User) fragment.getArguments().getSerializable("YOU");
        UID = fragment.getArguments().getString("UID");
    }

    ImageView img;
    TextView tv;
    EditText edtFullName, edtEmail, edtPhone, edtPassword;
    Firebase root, picRoot, messRoot;
    String userUID;
    Intent in;
    Bitmap bitmap;
    String email, password, phone, fullname, picture, data;
    String[] sp1, sp2;
    ArrayList<String> arr = new ArrayList<>();
    private static int RESULT_LOAD_IMAGE = 1;
    private int PICK_IMAGE_REQUEST = 1;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        img = (ImageView) getActivity().findViewById(R.id.imageView);
        tv = (TextView) getActivity().findViewById(R.id.textViewFullNameEditProfile);
        edtFullName = (EditText) getActivity().findViewById(R.id.editTextFullNameEditProfile);
        edtEmail = (EditText) getActivity().findViewById(R.id.editTextEmailEditProfile);
        edtPassword = (EditText) getActivity().findViewById(R.id.editTextPasswordEditProfile);
        edtPhone = (EditText) getActivity().findViewById(R.id.editTextPhoneEditProfile);

        tv.setText(u.getFullname());
        edtPhone.setText(u.getPhone());
        edtPassword.setText(u.getPassword());
        edtEmail.setText(u.getEmail());
        edtFullName.setText(u.getFullname());

        byte[] decodedString = Base64.decode(u.getPicture(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        img.setImageBitmap(decodedByte);

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
            }
        });

        //Button Cancel
        getActivity().findViewById(R.id.buttonCancelInTouch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.toContact(u);
            }
        });

        //Button Update
        getActivity().findViewById(R.id.buttonUpdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = new Firebase("https://group4-hw9.firebaseio.com/");
                picRoot = new Firebase("https://group4-hw9.firebaseio.com/users/"+UID+"/picture/");
                picRoot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        picture = dataSnapshot.getValue().toString();
//                        //Change code for the picture value
//                        //How to get img from an ImageView?
//                        Bitmap bitmapOrg = bitmap;
//                        ByteArrayOutputStream bao = new ByteArrayOutputStream();
//                        bitmapOrg.compress(Bitmap.CompressFormat.JPEG, 100, bao);
//                        byte[] ba = bao.toByteArray();
//                        picture = Base64.encodeToString(ba, Base64.DEFAULT);

                        BitmapDrawable drawable = (BitmapDrawable) img.getDrawable();
                        Bitmap bmap = drawable.getBitmap();
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        bmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
                        byte[] bb = bos.toByteArray();
                        picture = Base64.encodeToString(bb, Base64.DEFAULT);

                        email = edtEmail.getText().toString();
                        fullname = edtFullName.getText().toString();
                        password = edtPassword.getText().toString();
                        phone = edtPhone.getText().toString();
                        User user = new User(email, password, phone, fullname, picture);
                        Firebase editUser = root.child("users").child(UID);
                        editUser.setValue(user);
                        Toast.makeText(getActivity(), "Saved Successfully!", Toast.LENGTH_LONG).show();
                        mListener.toContact(u);
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == getActivity().RESULT_OK && data != null && data.getData() != null) {

            Uri uri = data.getData();

            try {
                bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));

                ImageView imageView = (ImageView) getActivity().findViewById(R.id.imageView);
                img.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
