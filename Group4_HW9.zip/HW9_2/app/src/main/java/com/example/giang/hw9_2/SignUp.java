package com.example.giang.hw9_2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

import java.io.ByteArrayOutputStream;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SignUp.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class SignUp extends Fragment {

    private OnFragmentInteractionListener mListener;

    public SignUp() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sign_up, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
        void toLogin();
    }

    Firebase ref;
    EditText edtName, edtEmail, edtPhone, edtPassword, edtConfirm;
    String name, email, phone, password, picture;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Firebase.setAndroidContext(getActivity());
        ref = new Firebase("https://group4-hw9.firebaseio.com/");

        //Cast
        edtConfirm = (EditText) getActivity().findViewById(R.id.editTextConfirmPassword);
        edtEmail = (EditText) getActivity().findViewById(R.id.editTextEmailSignUp);
        edtPassword = (EditText) getActivity().findViewById(R.id.editTextPasswordSignUp);
        edtName = (EditText) getActivity().findViewById(R.id.editTextName);
        edtPhone = (EditText) getActivity().findViewById(R.id.editTextPhone);

        //Set back to default when go back to create new account fragment
        edtEmail.setText("");
        edtPassword.setText("");
        edtConfirm.setText("");
        edtPhone.setText("");
        edtName.setText("");

        //Convert default image to base64
        Bitmap bitmapOrg = BitmapFactory.decodeResource(getResources(), R.drawable.defaimg);
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        bitmapOrg.compress(Bitmap.CompressFormat.JPEG, 100, bao);
        byte[] ba = bao.toByteArray();
        picture = Base64.encodeToString(ba, Base64.DEFAULT);

        //Button Cancel
        getActivity().findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.toLogin();
            }
        });

        //Button Sign Up
        getActivity().findViewById(R.id.buttonSignUp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Match password and confirm password
                if (!edtConfirm.getText().toString().equals(edtPassword.getText().toString())) {
                    Toast.makeText(getActivity(), "Please match your password", Toast.LENGTH_LONG).show();
                } else {

                    ref.createUser(edtEmail.getText().toString(), edtPassword.getText().toString(), new Firebase.ValueResultHandler<Map<String, Object>>() {
                        //Create new User
                        @Override
                        public void onSuccess(Map<String, Object> stringObjectMap) {
                            //Set up User object
                            email = edtEmail.getText().toString();
                            password = edtPassword.getText().toString();
                            phone = edtPhone.getText().toString();
                            name = edtName.getText().toString();
                            User user = new User(email, password, phone, name, picture);

                            //Create
                            ref.child("users").child(""+stringObjectMap.get("uid")).setValue(user);

                            Toast.makeText(getActivity(), "Success", Toast.LENGTH_SHORT).show();

                            //Go back to Login after success sign up
                            mListener.toLogin();
                        }

                        //Error
                        @Override
                        public void onError(FirebaseError firebaseError) {
                            Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }
}
