package com.example.giang.hw9_2;

/**
 * Created by Giang on 4/22/2016.
 */
public class StayInTouchObject {
    String picture, name, message_read, callPhone;

    @Override
    public String toString() {
        return "StayInTouchObject{" +
                ", name='" + name + '\'' +
                ", message_read='" + message_read + '\'' +
                ", callPhone='" + callPhone + '\'' +
                '}';
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage_read() {
        return message_read;
    }

    public void setMessage_read(String message_read) {
        this.message_read = message_read;
    }

    public String getCallPhone() {
        return callPhone;
    }

    public void setCallPhone(String callPhone) {
        this.callPhone = callPhone;
    }

    public StayInTouchObject() {

    }

    public StayInTouchObject(String picture, String name, String message_read, String callPhone) {

        this.picture = picture;
        this.name = name;
        this.message_read = message_read;
        this.callPhone = callPhone;
    }
}
