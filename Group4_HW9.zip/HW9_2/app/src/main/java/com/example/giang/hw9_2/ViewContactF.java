package com.example.giang.hw9_2;

import android.app.Fragment;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ViewContactF.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class ViewContactF extends Fragment {

    private OnFragmentInteractionListener mListener;

    public ViewContactF() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_view_contact, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    User otherUser;
    static ViewContactF viewContactF = new ViewContactF();

    public static ViewContactF newInstance(User otherUser) {

        Bundle args = new Bundle();
        args.putSerializable("OTHERUSER", otherUser);
        viewContactF.setArguments(args);

        return viewContactF;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        otherUser = (User) viewContactF.getArguments().getSerializable("OTHERUSER");
    }

    TextView tvName, tvName2, tvPhone, tvEmail;
    ImageView img;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        tvName = (TextView) getActivity().findViewById(R.id.textViewNameViewContact);
        tvName2 = (TextView) getActivity().findViewById(R.id.textViewName2ViewContact);
        tvPhone = (TextView) getActivity().findViewById(R.id.textViewPhoneViewContact);
        tvEmail = (TextView) getActivity().findViewById(R.id.textViewEmaillViewContact);
        img = (ImageView) getActivity().findViewById(R.id.imageView2);

        tvEmail.setText(" "+otherUser.getEmail());
        tvName2.setText(" "+otherUser.getFullname());
        tvName.setText(" "+otherUser.getFullname());
        tvPhone.setText(" "+otherUser.getPhone());

        //Set image profile
        byte[] decodedString = Base64.decode(otherUser.getPicture(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        img.setImageBitmap(decodedByte);
    }
}
