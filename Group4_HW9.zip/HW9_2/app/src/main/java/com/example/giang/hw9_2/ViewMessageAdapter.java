package com.example.giang.hw9_2;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.List;

/**
 * Created by gdao_000 on 4/15/2016.
 */
public class ViewMessageAdapter extends ArrayAdapter<MessageUserCombine> {
    Firebase root;
    List<MessageUserCombine> mData;
    Context mContext;
    int mResource;

    public ViewMessageAdapter(Context context, int resource, List<MessageUserCombine> objects) {
        super(context, resource, objects);
        mData = objects;
        mContext = context;
        mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null){
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);

            holder = new ViewHolder();
            holder.tvName = (TextView) convertView.findViewById(R.id.textViewNameViewMessage);
            holder.linearLayout = (LinearLayout) convertView.findViewById(R.id.linearLayout);
            holder.tvMessage = (TextView) convertView.findViewById(R.id.textViewMessageViewMessage);
            holder.tvTimeStamp = (TextView) convertView.findViewById(R.id.textViewtimeStampViewMessage);
            holder.img = (ImageView) convertView.findViewById(R.id.imageView3);
            convertView.setTag(holder);
        }

        final MessageUserCombine message = mData.get(position);
        holder = (ViewHolder) convertView.getTag();
        LinearLayout linearLayout = holder.linearLayout;
        TextView tvName = holder.tvName;
        TextView tvMessage = holder.tvMessage;
        TextView tvTimeStamp = holder.tvTimeStamp;
        ImageView img = holder.img;

        tvName.setText(message.getSender());
        tvName.setTypeface(null, Typeface.BOLD);
        tvMessage.setText(message.getMessage_text());
        tvTimeStamp.setText(message.getTimeStamp());
        if (message.getIsSender().equals("true")) {
            img.setVisibility(View.VISIBLE);
            linearLayout.setBackgroundColor(Color.LTGRAY);
        }else{
            img.setVisibility(View.GONE);
            linearLayout.setBackgroundColor(Color.WHITE);
        }

        //On click to delete the message
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = new Firebase("https://group4-homework08.firebaseio.com/Messages/");
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {
                            Message msg = postSnapshot.getValue(Message.class);
                            if (msg.getTimeStamp().equals(message.getTimeStamp()) && msg.getSender().equals(message.getSender()))
                                root.child(postSnapshot.getKey()).removeValue();
                        }
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });
            }
        });

        return convertView;
    }

    static class ViewHolder {
        TextView tvName, tvMessage, tvTimeStamp;
        ImageView img;
        LinearLayout linearLayout;
    }
}
