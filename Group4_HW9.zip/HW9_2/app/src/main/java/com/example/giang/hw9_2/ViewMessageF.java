package com.example.giang.hw9_2;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ViewMessageF.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class ViewMessageF extends Fragment {

    private OnFragmentInteractionListener mListener;

    public ViewMessageF() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_view_message, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    User u, otherUser;
    static ViewMessageF fragment = new ViewMessageF();

    public static ViewMessageF newInstance(User u, User otherUser) {

        Bundle args = new Bundle();
        args.putSerializable("YOU", u);
        args.putSerializable("OTHERUSER", otherUser);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        u = (User) fragment.getArguments().getSerializable("YOU");
        otherUser = (User) fragment.getArguments().getSerializable("OTHERUSER");
    }

    Firebase ref, msgRoot, convRoot;
    EditText edtMsg;
    ListView lv;
    MessageUserCombine messageUserCombine;
    ArrayList<MessageUserCombine> messageUserCombines;
    Conversation conversation;
    Activity activity;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Firebase.setAndroidContext(getActivity());
        ref = new Firebase("https://group4-hw9.firebaseio.com/");
        msgRoot = ref.child("Messages");
        convRoot = ref.child("Conversations");
        messageUserCombines = new ArrayList<>();
        edtMsg = (EditText) getActivity().findViewById(R.id.editTextMessage);
        lv = (ListView) getActivity().findViewById(R.id.listViewMessage);
        activity = getActivity();

        msgRoot.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                messageUserCombines.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Message message = postSnapshot.getValue(Message.class);

                    //Filter message to match user and user's current pick friend
                    if (message.getSender().equals(otherUser.getFullname()) && message.getReceiver().equals(u.getFullname())) {
                        messageUserCombine = new MessageUserCombine(otherUser.getFullname(), message.getMessage_text(), message.getTimeStamp(), "false");
                        messageUserCombines.add(messageUserCombine);
                    } else if (message.getReceiver().equals(otherUser.getFullname()) && message.getSender().equals(u.getFullname())) {
                        messageUserCombine = new MessageUserCombine(u.getFullname(), message.getMessage_text(), message.getTimeStamp(), "true");
                        messageUserCombines.add(messageUserCombine);
                    }
                }
                Log.d("demo", "Message User Combine: " + messageUserCombines.toString());
                ViewMessageAdapter viewMessageAdapter = new ViewMessageAdapter(activity, R.layout.message_listview, messageUserCombines);
                lv.setAdapter(viewMessageAdapter);
                viewMessageAdapter.setNotifyOnChange(true);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        //Button Send
        getActivity().findViewById(R.id.buttonSend).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtMsg.getText().toString().length() > 140) {
                    Toast.makeText(getActivity(), "Message need to be less than 140 characters!", Toast.LENGTH_LONG).show();
                } else {
                    Calendar c = Calendar.getInstance();
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String formattedDate = df.format(c.getTime());
                    Message newMessage = new Message(formattedDate, "false", edtMsg.getText().toString(), otherUser.getFullname(), u.getFullname());
                    msgRoot.push().setValue(newMessage);

                    convRoot.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot5) {
                            boolean isConversation = false;

                            for (DataSnapshot postSnapshot5 : dataSnapshot5.getChildren()) {
                                Conversation checkConv = postSnapshot5.getValue(Conversation.class);
                                Log.d("demo", checkConv.toString());
                                if (((checkConv.getParticipant1().equals(u.getEmail()) && checkConv.getParticipant2().equals(otherUser.getEmail()))
                                        || (checkConv.getParticipant1().equals(otherUser.getEmail()) && checkConv.getParticipant2().equals(u.getEmail())))) {
                                    isConversation = true;
                                    break;
                                }
                            }

                            if (isConversation == false) {
                                conversation = new Conversation("no", "no", "no", u.getEmail(), otherUser.getEmail());
                                convRoot.push().setValue(conversation);
                            }

                        }

                        @Override
                        public void onCancelled(FirebaseError firebaseError) {
                            Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });

                    edtMsg.setText("");
                }
            }
        });
    }
}
