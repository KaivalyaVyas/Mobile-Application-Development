package com.example.gdao_000.homework08;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class EditProfile extends AppCompatActivity {

    ImageView img;
    TextView tv;
    EditText edtFullName, edtEmail, edtPhone, edtPassword;
    Firebase root, picRoot, messRoot;
    String userUID;
    Intent in;
    Bitmap bitmap;
    String email, password, phone, fullname, picture, data;
    String[] sp1, sp2;
    ArrayList<String> arr = new ArrayList<>();
    private static int RESULT_LOAD_IMAGE = 1;
    private int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri uri = data.getData();

            try {
                 bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));

                ImageView imageView = (ImageView) findViewById(R.id.imageView);
                img.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        //Get user UID
        in = getIntent();
        userUID = in.getStringExtra("UID");

        //Cast
        img = (ImageView) findViewById(R.id.imageView);
     //   bitmap = img.getDrawingCache();
    //    ImageButton imb = (ImageButton)findViewById(R.id.imageButton);
        tv = (TextView) findViewById(R.id.textViewFullNameEditProfile);
        edtFullName = (EditText) findViewById(R.id.editTextFullNameEditProfile);
        edtEmail = (EditText) findViewById(R.id.editTextEmailEditProfile);
        edtPassword = (EditText) findViewById(R.id.editTextPasswordEditProfile);
        edtPhone = (EditText) findViewById(R.id.editTextPhoneEditProfile);










        /** Called when the activity is first created. */



        //Set up Firebase
        Firebase.setAndroidContext(this);
        root = new Firebase("https://group4-homework08.firebaseio.com/users/" + userUID);

        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //Log.d("demo", dataSnapshot.getValue().toString());
                data = dataSnapshot.getValue().toString();
                sp1 = data.split(",");
                //Log.d("demo", "" + sp1.length);

                for (int i = 0; i < sp1.length; i++) {
                    sp2 = sp1[i].split("=");
                    arr.add(sp2[0]);
                    arr.add(sp2[1]);
                }

                tv.setText(arr.get(3));
                edtPhone.setText(arr.get(1));
                edtFullName.setText(arr.get(3));
                edtEmail.setText(arr.get(5));
                edtPassword.setText(arr.get(7));
                byte[] decodedString = Base64.decode(arr.get(9), Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                img.setImageBitmap(decodedByte);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
                //ERROR
            }
        });

        //Set the new image here to open Gallery bullshit
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Access Gallery
  /*              Log.d("KDV", "Image clicked made by giang");
                Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, RESULT_LOAD_IMAGE);

                onActivityResult(RESULT_LOAD_IMAGE,RESULT_OK,i );
                {
        //            img.setImageResource();
                }
*/
                Intent intent = new Intent();
// Show only images, no videos or anything else
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
// Always show the chooser (if there are multiple options available)
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);





            }
        }


        );



        //Button Cancel
        findViewById(R.id.buttonCancelInTouch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //Button Update
        findViewById(R.id.buttonUpdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = new Firebase("https://group4-homework08.firebaseio.com/");
                picRoot = new Firebase("https://group4-homework08.firebaseio.com/users/" + userUID + "/picture");

                picRoot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        //Temporary picture -- NEED TO FIX
                        picture = dataSnapshot.getValue().toString();
                        //Change code for the picture value
                        //How to get img from an ImageView?
                         Bitmap bitmapOrg = bitmap;
                         ByteArrayOutputStream bao = new ByteArrayOutputStream();
                         bitmapOrg.compress(Bitmap.CompressFormat.JPEG, 100, bao);
                         byte[] ba = bao.toByteArray();
                         picture = Base64.encodeToString(ba, Base64.DEFAULT);



                        email = edtEmail.getText().toString();
                        fullname = edtFullName.getText().toString();
                        password = edtPassword.getText().toString();
                        phone = edtPhone.getText().toString();
                        User user = new User(email, password, phone, fullname, picture);
                        Firebase editUser = root.child("users").child(userUID);
                        editUser.setValue(user);
                        Toast.makeText(EditProfile.this, "Saved Successfully!", Toast.LENGTH_LONG).show();
                        finish();
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });
            }
        });
    }
}
