package com.example.gdao_000.homework08;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by gdao_000 on 4/15/2016.
 */
public class InTouchAdapter extends ArrayAdapter<UserMessageCombine> {
    List<UserMessageCombine> mData;
    Context mContext;
    int mResource;

    public InTouchAdapter(Context context, int resource, List<UserMessageCombine> objects) {
        super(context, resource, objects);
        mData = objects;
        mContext = context;
        mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);

            holder = new ViewHolder();

            holder.tv = (TextView) convertView.findViewById(R.id.textViewName);
            holder.imgPhone = (ImageView) convertView.findViewById(R.id.imageViewPhone);
            holder.imgProfile = (ImageView) convertView.findViewById(R.id.imageViewProfile);
            holder.imgRedDot = (ImageView) convertView.findViewById(R.id.imageViewRedDot);
            convertView.setTag(holder);
        }

        final UserMessageCombine userMessageCombine = mData.get(position);
        holder = (ViewHolder) convertView.getTag();
        TextView tvName = holder.tv;
        ImageView imgPhone = holder.imgPhone;
        ImageView imgRedDot = holder.imgRedDot;
        ImageView imgProf = holder.imgProfile;

        tvName.setText(userMessageCombine.getOtherUser());
        //Set image profile
        byte[] decodedString = Base64.decode(userMessageCombine.getPicture(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        imgProf.setImageBitmap(decodedByte);

        if (userMessageCombine.getMessage_read().equals("false")){
            imgRedDot.setVisibility(View.VISIBLE);
        } else{
            imgRedDot.setVisibility(View.INVISIBLE);
        }

        imgPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+userMessageCombine.getPhone()));
                //Log.d("demo1", user.getPhone()); CORRECT Phone #
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }

    static class ViewHolder {
        ImageView imgProfile, imgRedDot, imgPhone;
        TextView tv;
    }
}
