package com.example.gdao_000.homework08;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.AuthData;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    EditText edtEmail, edtPassword;
    Firebase root, userRoot;
    Firebase.AuthResultHandler authResultHandler;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Set up Firebase
        Firebase.setAndroidContext(this);
        root = new Firebase("https://group4-homework08.firebaseio.com/");

        edtEmail = (EditText) findViewById(R.id.editTextEmail);
        edtPassword = (EditText) findViewById(R.id.editTextPassword);

        edtEmail.setText("");
        edtPassword.setText("");

        //Button Create New Account
        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SignUp.class);
                startActivity(intent);
            }
        });

        //For Button Login
        root.addAuthStateListener(new Firebase.AuthStateListener() {
            @Override
            public void onAuthStateChanged(AuthData authData) {
                if (authData != null){
                    userRoot = new Firebase("https://group4-homework08.firebaseio.com/users/"+authData.getUid()+"/");
                    userRoot.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            user = dataSnapshot.getValue(User.class);
                            Intent intent = new Intent(MainActivity.this, StayInTouch.class);
                            Log.d("kdv",""+user.getFullname());
                            intent.putExtra("USER", user);
                            intent.putExtra("UID", dataSnapshot.getKey().toString());
                            startActivity(intent);
                            finish();
                        }

                        @Override
                        public void onCancelled(FirebaseError firebaseError) {

                        }
                    });

                } else{
                    authResultHandler = new Firebase.AuthResultHandler() {
                        @Override
                        public void onAuthenticated(final AuthData authData) {
                            userRoot = new Firebase("https://group4-homework08.firebaseio.com/users/"+authData.getUid()+"/");
                            userRoot.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    user = dataSnapshot.getValue(User.class);
                                    Intent intent = new Intent(MainActivity.this, StayInTouch.class);
                                    intent.putExtra("USER", user);
                                    intent.putExtra("UID", dataSnapshot.getKey().toString());
                                    startActivity(intent);
                                    finish();
                                }

                                @Override
                                public void onCancelled(FirebaseError firebaseError) {

                                }
                            });
                        }

                        @Override
                        public void onAuthenticationError(FirebaseError firebaseError) {
                            Toast.makeText(getApplicationContext(),
                                    firebaseError.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    };
                    findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            root.authWithPassword(edtEmail.getText().toString(), edtPassword.getText().toString(), authResultHandler);
                        }
                    });
                }
            }
        });
    }
}
