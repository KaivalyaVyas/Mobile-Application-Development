package com.example.gdao_000.homework08;

import java.io.Serializable;

/**
 * Created by gdao_000 on 4/15/2016.
 */
public class Message implements Serializable{
    String timeStamp, message_read, message_text, receiver, sender;

    @Override
    public String toString() {
        return "Message{" +
                "timeStamp='" + timeStamp + '\'' +
                ", message_read='" + message_read + '\'' +
                ", message_text='" + message_text + '\'' +
                ", receiver='" + receiver + '\'' +
                ", sender='" + sender + '\'' +
                '}';
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getMessage_read() {
        return message_read;
    }

    public void setMessage_read(String message_read) {
        this.message_read = message_read;
    }

    public String getMessage_text() {
        return message_text;
    }

    public void setMessage_text(String message_text) {
        this.message_text = message_text;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public Message() {

    }

    public Message(String timeStamp, String message_read, String message_text, String receiver, String sender) {

        this.timeStamp = timeStamp;
        this.message_read = message_read;
        this.message_text = message_text;
        this.receiver = receiver;
        this.sender = sender;
    }
}
