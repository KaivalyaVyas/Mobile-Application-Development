package com.example.gdao_000.homework08;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

import java.io.ByteArrayOutputStream;
import java.util.Map;

public class SignUp extends AppCompatActivity {

    EditText edtName, edtEmail, edtPassword, edtConfirmPassword, edtPhone;
    Firebase root;
    String email, password, phone, fullname, picture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //Set up Firebase
        Firebase.setAndroidContext(this);
        root = new Firebase("https://group4-homework08.firebaseio.com/");

        //Cast variables
        edtName = (EditText) findViewById(R.id.editTextName);
        edtEmail = (EditText) findViewById(R.id.editTextEmailSignUp);
        edtPassword = (EditText) findViewById(R.id.editTextPasswordSignUp);
        edtConfirmPassword = (EditText) findViewById(R.id.editTextConfirmPassword);
        edtPhone = (EditText) findViewById(R.id.editTextPhone);

        edtEmail.setText("");
        edtPassword.setText("");
        edtConfirmPassword.setText("");
        edtPhone.setText("");
        edtName.setText("");

        //Convert image to base64 string
        Bitmap bitmapOrg = BitmapFactory.decodeResource(getResources(), R.drawable.defaimg);
        ByteArrayOutputStream bao = new ByteArrayOutputStream();
        bitmapOrg.compress(Bitmap.CompressFormat.JPEG, 100, bao);
        byte [] ba = bao.toByteArray();
        picture=Base64.encodeToString(ba, Base64.DEFAULT);

        /* Convert base64 to Bitmap
        byte[] decodedString = Base64.decode(picture, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        img.setImageBitmap(decodedByte);
        */

        //Button Cancel
        findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //Button SignUp
        findViewById(R.id.buttonSignUp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edtConfirmPassword.getText().toString().equals(edtPassword.getText().toString())){
                    Toast.makeText(SignUp.this, "Confirm Password does not match", Toast.LENGTH_LONG).show();
                }else{
                    root.createUser(edtEmail.getText().toString(), edtPassword.getText().toString(), new Firebase.ValueResultHandler<Map<String, Object>>() {
                        @Override
                        public void onSuccess(Map<String, Object> stringObjectMap) {
                            //Set User Object
                            email = edtEmail.getText().toString();
                            password = edtPassword.getText().toString();
                            phone = edtPhone.getText().toString();
                            fullname = edtName.getText().toString();
                            User user = new User(email, password, phone, fullname, picture);
                            //Log.d("demo", ""+stringObjectMap.get("uid"));
                            //Log.d("demo", user.toString());

                            //Add user to database
                            Firebase newUser = root.child("users").child(""+stringObjectMap.get("uid"));
                            newUser.setValue(user);

                            //Toast success
                            Toast.makeText(SignUp.this, "Success", Toast.LENGTH_SHORT).show();
                            finish();
                        }

                        @Override
                        public void onError(FirebaseError firebaseError) {
                            //Toast Error
                            Toast.makeText(getApplicationContext(),
                                    firebaseError.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }
}
