package com.example.gdao_000.homework08;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

public class StayInTouch extends AppCompatActivity {

    Firebase root, msgRoot;
    String userUID;
    User u;
    Intent in;
    ArrayList<User> users = new ArrayList<>();
    ArrayList<Message> messages = new ArrayList<>();
    ListView lv;
    InTouchAdapter inTouchAdapter;
    UserMessageCombine userMessageCombine;
    String otherUser, picture, message_read, phone;
    ArrayList<UserMessageCombine> userMessageCombines = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stay_in_touch);

        //Set up Firebase
        Firebase.setAndroidContext(this);
        root = new Firebase("https://group4-homework08.firebaseio.com/users/");
        msgRoot = new Firebase("https://group4-homework08.firebaseio.com/Messages/");

        lv = (ListView) findViewById(R.id.listViewInTouch);
        in = getIntent();
        u = (User) in.getSerializableExtra("USER");
        userUID = in.getStringExtra("UID");
        Log.d("demoUserUID", userUID);
        Log.d("demoU", u.toString());

        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    User user = postSnapshot.getValue(User.class);

                    //This wont show the user himself because email is unique
                    if(!user.getEmail().equals(u.getEmail())) {
                        users.add(user);
                    }
                }

                msgRoot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot2) {
                        for (DataSnapshot postSnapshotMsg: dataSnapshot2.getChildren()){
                            Message msg = postSnapshotMsg.getValue(Message.class);

                            //Only take msg that have same receiver or sender name with the logged in user
                            if(msg.getReceiver().equals(u.getFullname()) || msg.getSender().equals(u.getFullname())) {
                                messages.add(msg);
                            }
                        }

                        for (User user: users){
                            picture = user.getPicture();
                            phone = user.getPhone();
                            otherUser = user.getFullname();
                            if (!messages.isEmpty()) {
                                int i = 0;
                                for (Message message : messages) {
                                    //Filter for each user

                                    Log.d("kdv",""+message.getReceiver());
                                    Log.d("kdv",""+u.getFullname());
                                    Log.d("kdv",""+message.getSender());
                                    if ((i<2) && (message.getReceiver().equals(u.getFullname()) || message.getSender().equals(u.getFullname()))) {
                                        if (message.getReceiver().equals(u.getFullname())) {

                                            message_read = message.getMessage_read();

                                              Log.d("kdv","if"+message_read);
                                        }
                                        else if (message.getSender().equals(u.getFullname()))
                                        {
                                            message_read = "true";
                                            Log.d("kdv","else");
                                        }
                                        i = i+1;
                                    }
                                }
                            } else{
                                message_read = "true";
                            }
                            userMessageCombine = new UserMessageCombine(otherUser, picture, message_read, phone);
                            userMessageCombines.add(userMessageCombine);
                        }

                        //Handling duplicate users
                       /* int a = userMessageCombines.size();
                        for (int i = 0; i<a-1; i++){
                            for (int j = i+1; j<a; j++){
                                UserMessageCombine userMessageCombine1 = userMessageCombines.get(i);
                                UserMessageCombine userMessageCombine2 = userMessageCombines.get(j);

                                if (userMessageCombine1.getOtherUser().equals(userMessageCombine2.getOtherUser())){
                                    userMessageCombines.remove(i);
                                    break;
                                }
                            }
                        }*/

                        Log.d("demo", userMessageCombines.toString());

                        inTouchAdapter = new InTouchAdapter(StayInTouch.this, R.layout.custom_listview, userMessageCombines);
                        lv.setAdapter(inTouchAdapter);
                        inTouchAdapter.setNotifyOnChange(true);

                        //List View On Click
                        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                                msgRoot.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot3) {
                                        for (DataSnapshot postSnapshot: dataSnapshot3.getChildren()){
                                            Message msg = postSnapshot.getValue(Message.class);
                                            if (msg.getSender().equals(users.get(position).getFullname()) && msg.getReceiver().equals(u.getFullname()))
                                                msgRoot.child(postSnapshot.getKey()).child("message_read").setValue("true");

                                        }
                                    }

                                    @Override
                                    public void onCancelled(FirebaseError firebaseError) {

                                    }
                                });

                                Intent intent = new Intent(StayInTouch.this, ViewMessages.class);
                                intent.putExtra("MESSAGE", (Serializable) messages);
                                intent.putExtra("OTHER_USER", users.get(position));
                                intent.putExtra("USER", u);
                                startActivity(intent);
                            }
                        });
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mymenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.editProfile:
                Intent intent1 = new Intent(StayInTouch.this, EditProfile.class);
                intent1.putExtra("UID", userUID);
                startActivity(intent1);
                return true;

            case R.id.logout:
                Firebase ref = new Firebase("https://group4-homework08.firebaseio.com/");
                ref.unauth();
                Intent intent = new Intent(StayInTouch.this, MainActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
