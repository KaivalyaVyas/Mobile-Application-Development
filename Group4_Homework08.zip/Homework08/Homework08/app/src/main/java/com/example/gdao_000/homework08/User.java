package com.example.gdao_000.homework08;

import java.io.Serializable;

/**
 * Created by gdao_000 on 4/14/2016.
 */
public class User implements Serializable{
    public String email, password, phone, fullname, picture;

    public User(String email, String password, String phone, String fullname, String picture) {
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.fullname = fullname;
        this.picture = picture;
    }

    public User() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    @Override
    public String toString() {
        return "User{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", phone='" + phone + '\'' +
                ", fullname='" + fullname + '\'' +
                '}';
    }
}
