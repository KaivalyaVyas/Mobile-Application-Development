package com.example.gdao_000.homework08;

/**
 * Created by gdao_000 on 4/15/2016.
 */
public class UserMessageCombine {
    String otherUser, picture, message_read, phone;

    @Override
    public String toString() {
        return "UserMessageCombine{" +
                "otherUser='" + otherUser + '\'' +
                ", message_read='" + message_read + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }

    public String getOtherUser() {
        return otherUser;
    }

    public void setOtherUser(String otherUser) {
        this.otherUser = otherUser;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getMessage_read() {
        return message_read;
    }

    public void setMessage_read(String message_read) {
        this.message_read = message_read;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public UserMessageCombine() {

    }

    public UserMessageCombine(String otherUser, String picture, String message_read, String phone) {

        this.otherUser = otherUser;
        this.picture = picture;
        this.message_read = message_read;
        this.phone = phone;
    }
}
