package com.example.gdao_000.homework08;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.TextView;

public class ViewContact extends AppCompatActivity {

    Intent in;
    User otherUser;
    TextView tvName, tvName2, tvEmail, tvPhone;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_contact);

        //Cast
        tvName = (TextView) findViewById(R.id.textViewNameViewContact);
        tvName2 = (TextView) findViewById(R.id.textViewName2ViewContact);
        tvEmail = (TextView) findViewById(R.id.textViewEmaillViewContact);
        tvPhone = (TextView) findViewById(R.id.textViewPhoneViewContact);
        img = (ImageView) findViewById(R.id.imageView2);


        in = getIntent();
        otherUser = (User) in.getSerializableExtra("OTHER_USER");

        tvName.setText(" "+otherUser.getFullname());
        tvName2.setText(" "+otherUser.getFullname());
        tvEmail.setText(" "+otherUser.getEmail());
        tvPhone.setText(" "+otherUser.getPhone());
        //Set image profile
        byte[] decodedString = Base64.decode(otherUser.getPicture(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        img.setImageBitmap(decodedByte);

    }
}
