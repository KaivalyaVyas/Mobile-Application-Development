package com.example.gdao_000.homework08;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ViewMessages extends AppCompatActivity {

    Intent in;
    User otheruser, u;
    String userUID;
    Firebase root, userRoot;
    Message newMessage;
    EditText edt;
    ArrayList<Message> messages = new ArrayList<>();
    ListView lv;
    MessageUserCombine messageUserCombine;
    ArrayList<MessageUserCombine> messageUserCombines;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_messages);

        messageUserCombines = new ArrayList<>();
        in = getIntent();
        userUID = in.getStringExtra("UID");
        otheruser = (User) in.getExtras().getSerializable("OTHER_USER");
        u = (User) in.getSerializableExtra("USER");

        //Set up Firebase
        Firebase.setAndroidContext(this);
        root = new Firebase("https://group4-homework08.firebaseio.com/Messages/");

        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                messageUserCombines.clear();
                for (DataSnapshot postSnapshot: dataSnapshot.getChildren()){
                    Message message = postSnapshot.getValue(Message.class);

                    //Filter message to match user and user's current pick friend
                    if (message.getSender().equals(otheruser.getFullname())){
                        messageUserCombine = new MessageUserCombine(otheruser.getFullname(), message.getMessage_text(), message.getTimeStamp(), "false");
                        messageUserCombines.add(messageUserCombine);
                    }else if(message.getReceiver().equals(otheruser.getFullname())){
                        messageUserCombine = new MessageUserCombine(u.getFullname(),message.getMessage_text(), message.getTimeStamp(), "true");
                        messageUserCombines.add(messageUserCombine);
                    }
                }

                ViewMessageAdapter viewMessageAdapter = new ViewMessageAdapter(ViewMessages.this, R.layout.custom_listview_viewmessage, messageUserCombines);
                lv = (ListView) findViewById(R.id.listViewMessage);
                lv.setAdapter(viewMessageAdapter);
                viewMessageAdapter.setNotifyOnChange(true);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });

        edt = (EditText) findViewById(R.id.editTextMessage);

        //Button Send
        findViewById(R.id.buttonSend).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String formattedDate = df.format(c.getTime());
                newMessage = new Message(formattedDate, "false", edt.getText().toString(), otheruser.getFullname(), u.getFullname());
                root.push().setValue(newMessage);
                edt.setText("");
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mymenu2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.viewContact:
                Intent intent1 = new Intent(ViewMessages.this, ViewContact.class);
                intent1.putExtra("OTHER_USER", otheruser);
                startActivity(intent1);
                return true;

            case R.id.callContact:
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + otheruser.getPhone()));
                //Log.d("demo", otheruser.getPhone()); CORRECT Phone #
                startActivity(intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
