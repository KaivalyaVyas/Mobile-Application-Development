package com.example.shruj.pizzastore;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    final static String TOPPING_KEY = "toppings";
    final static String DELIVERY_KEY = "delivery";
    TableLayout tableLayout1, tableLayout2;
    int item = 0;
    final int Row = 2;
    final int Column = 5;
    ArrayList<String> toppingsSelected = new ArrayList<String>();

    ImageView imageView;
    TableRow tableRow1, tableRow2;
    ProgressBar progressBar;
    CheckBox checkbox;

    CharSequence[] toppingsList = {"Bacon", "Cheese", "Garlic", "Green Pepper", "Mushroom", "Olives", "Onions", "Red Pepper", "Tomatoes"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(Boolean.TRUE);
        actionBar.setIcon(R.drawable.app_icon);

        final TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(150, 150);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        checkbox = (CheckBox) findViewById(R.id.checkBoxDelivery);
        progressBar.setMax(10);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        alertDialogBuilder.setTitle("Choose a Topping")
                .setItems(toppingsList, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        tableLayout1 = new TableLayout(MainActivity.this);
                        tableLayout2 = new TableLayout(MainActivity.this);


                        imageView = new ImageView(MainActivity.this);


                        tableRow1 = (TableRow) findViewById(R.id.tableRow1);
                        tableRow2 = (TableRow) findViewById(R.id.tableRow2);


                        switch (which) {

                            case 0:
                                imageView.setImageResource(R.drawable.bacon);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;
                            case 1:
                                imageView.setImageResource(R.drawable.cheese);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;
                            case 2:
                                imageView.setImageResource(R.drawable.garlic);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;

                            case 3:
                                imageView.setImageResource(R.drawable.green_pepper);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;
                            case 4:
                                imageView.setImageResource(R.drawable.mushroom);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;
                            case 5:
                                imageView.setImageResource(R.drawable.olives);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;
                            case 6:
                                imageView.setImageResource(R.drawable.onion);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;
                            case 7:
                                imageView.setImageResource(R.drawable.red_pepper);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;
                            default:
                                imageView.setImageResource(R.drawable.tomato);
                                toppingsSelected.add((String) toppingsList[which]);
                                item++;
                                break;
                        }

                        imageView.setLayoutParams(layoutParams);


                        if (item <= 5) {
                            tableRow1.addView(imageView);
                            progressBar.setProgress(item);

                        } else if (item > 5 && item <= 10) {
                            tableRow2.addView(imageView);
                            progressBar.setProgress(item);
                        } else {
                            Toast.makeText(getApplicationContext(), "Maximum Topping capacity reached!", Toast.LENGTH_SHORT).show();
                        }


                    }
                });

        final AlertDialog alertDialog = alertDialogBuilder.create();

        findViewById(R.id.buttonAddTopping).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.show();
            }
        });

        findViewById(R.id.buttonCheckOut).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putStringArrayListExtra(TOPPING_KEY, toppingsSelected);
                intent.putExtra(DELIVERY_KEY, checkbox.isChecked());
                startActivity(intent);

            }
        });

        findViewById(R.id.buttonClearPizza).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableRow1.removeAllViews();
                tableRow2.removeAllViews();
                progressBar.setProgress(0);
                item = 0;
                checkbox.setChecked(Boolean.FALSE);
            }
        });


    }
}


