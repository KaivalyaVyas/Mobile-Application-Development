package com.example.shruj.pizzastore;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView baseprice = (TextView) findViewById(R.id.base_price_value);
        TextView toppings = (TextView) findViewById(R.id.topping_list);
        TextView toppings_value = (TextView) findViewById(R.id.toppings_value);
        TextView delivery_Cost = (TextView) findViewById(R.id.Delivery_Value);
        TextView tot_dis = (TextView) findViewById(R.id.Total_Value);

        Intent intent = getIntent();
        Log.d("demo", "Second");

        if (getIntent().getExtras() != null) {

            boolean a = true;
            float delivery;
            ArrayList<String> topping_list = intent.getStringArrayListExtra(MainActivity.TOPPING_KEY);  //to be changed
            Log.d("demo", "Arr0");
            boolean b = intent.getBooleanExtra(MainActivity.DELIVERY_KEY, false); // to be changed
            Log.d("demo", "Arr1");
            if (b == a) {
                delivery = (float) 4.0;
            } else {
                delivery = (float) 0.00;
            }

            float topping_int = (float) (topping_list.size() * 1.5);

            baseprice.setText("6.5 $");

            delivery_Cost.setText(delivery + " $");
            toppings_value.setText(topping_int + " $");

            double total = (double) 6.5 + (double) delivery + topping_int * (double) 1.5;
            tot_dis.setText(total + " $");

            String all_toppings = "";
            for (int i = 1; i <= topping_list.size(); i++) {
                //
                all_toppings = all_toppings.concat(topping_list.get(i));

            }
            tot_dis.setText(all_toppings);

        } else {

            baseprice.setText("6.5 $");

            delivery_Cost.setText("4.0 $");

            double total = (double) 6.5 + (double) 4.0;
            tot_dis.setText(total + " $");

        }


        Button finish = (Button) findViewById(R.id.Finish);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });
    }

}
