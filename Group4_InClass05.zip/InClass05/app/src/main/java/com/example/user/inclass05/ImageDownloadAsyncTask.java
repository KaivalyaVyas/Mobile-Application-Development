/*Inclass Assignment5
  Kaivalya Vyas
*
* Student id 800936482
* */


package com.example.user.inclass05;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.renderscript.Sampler;
import android.support.v4.os.AsyncTaskCompat;
import android.os.*;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * Created by user on 2/15/2016.
 */
public class ImageDownloadAsyncTask extends AsyncTask<String,Void,HashMap<String,Bitmap>>{

    MainActivity activity;

    public ImageDownloadAsyncTask(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    protected HashMap<String, Bitmap> doInBackground(String... params) {

        Bitmap bmp;
        InputStream is ;
        BufferedReader br;

       // Log.d("DemoinnerPending",""+params[0]);
       // Log.d("DemoinnerPending",""+params[1]);


HashMap<String,Bitmap> hashmap = new HashMap<String,Bitmap>();
        HashMap<String,String> hashmap_string = new HashMap<String,String>();

        try{

            URL url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder bldr = new StringBuilder();
            String line = "";

//Log.d("DemoinnerClassline", "" + br.readLine());
           String s = "";
            while ((line = br.readLine()) != null)
            {

                bldr.append(line + " \n");
               // Log.d("DemoinnerClass", "" + bldr);
                s = line;
               //Log.d("DemoinnerClassline",""+s);


            }

            ArrayList<String> key = new ArrayList<String>();
            ArrayList<String> value = new ArrayList<String>();
            String temp;

            Log.d("NewString",""+s.indexOf(";"));
            int k;
            for(k=0;k<s.lastIndexOf(";");k=s.indexOf(";"))
            {
                int i = 0;
                temp = s.substring(i, s.indexOf(";"));
                // i = s.indexOf(";")+1;
                s= s.substring(s.indexOf(";")+1,s.length()-s.indexOf(";"));
               // Log.d("DemoinnerClassline",""+temp);
                //key.add(k+1, temp.substring(0, temp.indexOf(",")));
                //value.add(k+1, temp.substring(temp.indexOf(",") + 1, temp.length()));
                 String ks = new String("");
                ks = (new Integer(k)).toString();
              //  hashmap_string.put(temp.substring(0, temp.indexOf(",")).concat(ks) , temp.substring(temp.indexOf(",") + 1, temp.length()));

                URL url1 = new URL(temp.substring(temp.indexOf(",") + 1, temp.length()));
                HttpURLConnection con1 = (HttpURLConnection)url1.openConnection();
                con.setRequestMethod("GET");
                is = con.getInputStream();
                bmp = BitmapFactory.decodeStream(is);

               if(temp.substring(0, temp.indexOf(",")).contains(params[1]) )
                   Log.d("Inside Hashmap","");
                hashmap.put(temp.substring(0, temp.indexOf(",")).concat(ks),bmp);
                Log.d("Inside Hashmap Key", ""+temp.substring(0, temp.indexOf(",")).concat(ks));


            }



        }
       catch (IOException e) {
            e.printStackTrace();
        }


        return hashmap;
    }


    @Override
    protected void onPostExecute(HashMap<String,Bitmap> bitmaps)

    {
        super.onPostExecute(bitmaps);

        /**
         *
         * UNCC0 is not hard coding it is just try to verify the data is set to Image or not please do not consider as hard coding
         */



        Bitmap bmp = bitmaps.get("UNCC0");
        ImageView iv = (ImageView)activity.findViewById(R.id.imageView);
        Log.d("Demo","No data "+bitmaps);

      if(bmp != null) {
          iv.setImageBitmap(bmp);
          Log.d("Demo", "Yes data ");
      }
      else
      {
          Log.d("Demo","No data ");
      }

    }
}
