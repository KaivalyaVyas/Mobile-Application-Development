/*Inclass Assignment5
  Kaivalya Vyas
*
* Student id 800936482
* */

package com.example.user.inclass05;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      final ImageDownloadAsyncTask obj =  new ImageDownloadAsyncTask(this);
        final Button Go = (Button)findViewById(R.id.Go);


        Go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ConnectionCheck())
                {
                    Go.setEnabled(false);
                    EditText et = (EditText)findViewById(R.id.Search);
                    String imageTyep = et.getText().toString();

                    obj.execute("http://dev.theappsdr.com/apis/spring_2016/inclass5/URLs.txt",imageTyep);

                   /* EditText et = (EditText)findViewById(R.id.Search);
                    if(et != null)
                    {

                    }
                   else
                    {
                        Toast.makeText(MainActivity.this,"Please enter value in SearchboX",Toast.LENGTH_LONG).show();
                    }
*/



                }
                else
                {
                    Toast.makeText(MainActivity.this,"Not Connected to Internet",Toast.LENGTH_LONG).show();
                }
            }
        });


    }


    protected boolean ConnectionCheck()
    {

        boolean b;
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo nif = cm.getActiveNetworkInfo();

        if(nif == null)

        {
            b = false;
        }

        else
        {
            b= true;
        }

        return b;
    }


}
