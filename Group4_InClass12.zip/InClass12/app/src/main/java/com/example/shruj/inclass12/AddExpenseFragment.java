package com.example.shruj.inclass12;

import android.app.DatePickerDialog;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.firebase.client.AuthData;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.Calendar;


public class AddExpenseFragment extends Fragment {


    EditText expenseName;
    EditText amount;
    EditText date;
    Expense expense;
    Spinner spinner;
    Calendar calendar = Calendar.getInstance();
    DatePickerDialog departureDatePicker;
    Firebase ref, auth;

    private OnFragmentInteractionListener mListener;

    public AddExpenseFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_expense, container, false);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void goToExpenseListFragment();

        void goToAddExpenseFragment();
    }

    Firebase userRoot;
    User user;
    String emailAdd;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);
        spinner = (Spinner) getActivity().findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(), R.array.spinnerList, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        date = (EditText) getActivity().findViewById(R.id.editTextDate);

        if (getActivity() instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) getActivity();
        } else {
            throw new RuntimeException(getActivity().toString()
                    + " must implement OnFragmentInteractionListener");
        }

        departureDatePicker = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String year1 = String.valueOf(year);
                String month1 = String.valueOf(monthOfYear + 1);
                String day1 = String.valueOf(dayOfMonth);
                date.setText(month1 + "/" + day1 + "/" + year1);
            }
        }, calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));

        ref = new Firebase("https://inclass12.firebaseio.com/Expenses/");
        auth = new Firebase("https://inclass12.firebaseio.com/");

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                departureDatePicker.show();
            }
        });

        getActivity().findViewById(R.id.buttonAddeExpense).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expenseName = (EditText) getActivity().findViewById(R.id.editTextName);
                amount = (EditText) getActivity().findViewById(R.id.editTextAmount);
                date = (EditText) getActivity().findViewById(R.id.editTextDate);


                if (expenseName.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Please enter Expense Name", Toast.LENGTH_SHORT).show();
                } else if (amount.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Please enter amount", Toast.LENGTH_SHORT).show();
                } else if (date.getText().toString().equalsIgnoreCase("")) {
                    Toast.makeText(getActivity(), "Please enter date", Toast.LENGTH_SHORT).show();
                } else {
                    expense = new Expense();

                    expense.setName(expenseName.getText().toString());
                    expense.setAmount(amount.getText().toString());
                    expense.setDate(date.getText().toString());
                    expense.setCategory(spinner.getSelectedItem().toString());

                    auth.addAuthStateListener(new Firebase.AuthStateListener() {

                        @Override
                        public void onAuthStateChanged(AuthData authData) {

                            userRoot = new Firebase("https://inclass12.firebaseio.com/users/" + authData.getUid() + "/");
                            userRoot.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    user = dataSnapshot.getValue(User.class);
                                    emailAdd = user.getEmail();
                                    expense.setUser(emailAdd);
                                    ref.push().setValue(expense);
                                    mListener.goToExpenseListFragment();
                                }

                                @Override
                                public void onCancelled(FirebaseError firebaseError) {

                                }
                            });
                        }

                    });

                }
            }
        });
    }
}
