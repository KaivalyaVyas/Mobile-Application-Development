package com.example.shruj.inclass12;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class DetailedFragment extends Fragment {
    private OnFragmentInteractionListener mListener;

    TextView name;
    TextView category;
    TextView amount;
    TextView date;

    Expense expense;

    public DetailedFragment() {
        // Required empty public constructor
    }

    public static DetailedFragment newInstance(Expense expense) {
        DetailedFragment fragment = new DetailedFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable("Value", expense);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_detailed, container, false);

        name = (TextView) view.findViewById(R.id.text_name);
        category = (TextView) view.findViewById(R.id.text_cat);
        amount = (TextView) view.findViewById(R.id.text_amount);
        date = (TextView) view.findViewById(R.id.text_date);

        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void goToExpenseDetailedFragment(Expense expense);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            expense = getArguments().getParcelable("Value");
        }

        name = (TextView) getActivity().findViewById(R.id.text_name);
        category = (TextView) getActivity().findViewById(R.id.text_cat);
        amount = (TextView) getActivity().findViewById(R.id.text_amount);
        date = (TextView) getActivity().findViewById(R.id.text_date);

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        name.setText(expense.getName());
        category.setText(expense.getCategory());
        amount.setText(expense.getAmount());
        date.setText(expense.getDate());

    }
}
