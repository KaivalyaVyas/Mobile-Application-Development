package com.example.shruj.inclass12;

import android.os.Parcel;
import android.os.Parcelable;


public class Expense implements Parcelable {
    String amount;
    String category;
    String date;
    String name;
    String user;

    public Expense() {

    }


    protected Expense(Parcel in) {
        amount = in.readString();
        category = in.readString();
        date = in.readString();
        name = in.readString();
        user = in.readString();
    }

    public static final Creator<Expense> CREATOR = new Creator<Expense>() {
        @Override
        public Expense createFromParcel(Parcel in) {
            return new Expense(in);
        }

        @Override
        public Expense[] newArray(int size) {
            return new Expense[size];
        }
    };

    public String getAmount() {
        return amount;
    }


    public String getCategory() {
        return category;
    }


    public String getDate() {
        return date;
    }


    public String getName() {
        return name;
    }


    public String getUser() {
        return user;
    }

    @Override
    public String toString() {
        return "Expense{" +
                "amount='" + amount + '\'' +
                ", category='" + category + '\'' +
                ", date='" + date + '\'' +
                ", name='" + name + '\'' +
                ", user='" + user + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(amount);
        dest.writeString(category);
        dest.writeString(date);
        dest.writeString(name);
        dest.writeString(user);
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
