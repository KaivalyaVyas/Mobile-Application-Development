package com.example.shruj.inclass12;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.List;


public class ExpenseAdapter extends ArrayAdapter<Expense> {
    List<Expense> mData;
    Context mContext;
    int mResource;

    public ExpenseAdapter(Context context, int resource, List<Expense> objects) {
        super(context, resource, objects);
        this.mContext = context;
        this.mData = objects;
        this.mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);
        }

        NumberFormat format = NumberFormat.getCurrencyInstance();

        Expense expense = mData.get(position);
        TextView nameText = (TextView) convertView.findViewById(R.id.nameTextView);
        TextView amountText = (TextView) convertView.findViewById(R.id.amountTextView);

        String formattedMoney = format.format(Double.valueOf(expense.getAmount()));

        nameText.setText(expense.name);

        amountText.setText(formattedMoney);


        return convertView;
    }
}