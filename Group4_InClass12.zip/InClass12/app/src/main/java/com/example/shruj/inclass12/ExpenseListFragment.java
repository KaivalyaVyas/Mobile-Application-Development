package com.example.shruj.inclass12;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.firebase.client.AuthData;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ExpenseListFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class ExpenseListFragment extends Fragment  {

    Firebase ref, auth, userRoot;
    ArrayList<Expense> expenses;
    ListView lv;

    private OnFragmentInteractionListener mListener;

    public ExpenseListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_expense_list, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event


    @Override
    public void onAttach(Activity context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void goToExpenseDetailedFragment(Expense expense);
    }


    User user;
    String email;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        lv = (ListView) getActivity().findViewById(R.id.expenseListView);

        ref = new Firebase("https://inclass12.firebaseio.com/Expenses/");
        auth = new Firebase("https://inclass12.firebaseio.com/");

        expenses = new ArrayList<>();


        auth.addAuthStateListener(new Firebase.AuthStateListener() {
            @Override
            public void onAuthStateChanged(AuthData authData) {
                userRoot = new Firebase("https://inclass12.firebaseio.com/users/" + authData.getUid() + "/");
                userRoot.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        user = dataSnapshot.getValue(User.class);
                        email = user.getEmail();
                        ref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot snapshot) {
                                Log.d("firebase", "There are " + snapshot.getChildrenCount() + " blog posts");
                                Log.d("snapshot", snapshot.toString());
                                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                                    Expense expense = postSnapshot.getValue(Expense.class);
                                    if (expense.getUser().equals(email)) {
                                        expenses.add(expense);
                                    }
                                    Log.d("firebase", expense.toString());
                                }
                                ExpenseAdapter adapter = new ExpenseAdapter(getActivity(), R.layout.row_item_list, expenses);
                                lv.setAdapter(adapter);

                                adapter.setNotifyOnChange(Boolean.TRUE);

                            }

                            @Override
                            public void onCancelled(FirebaseError firebaseError) {
                                Log.d("firebase", "The read failed: " + firebaseError.getMessage());
                            }
                        });
                    }

                    @Override
                    public void onCancelled(FirebaseError firebaseError) {

                    }
                });

            }
        });


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("onclick", "onclick" + expenses.get(position).toString());

                mListener.goToExpenseDetailedFragment(expenses.get(position));
            }
        });


    }
}
