package com.example.shruj.inclass12;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.firebase.client.AuthData;
import com.firebase.client.Firebase;

public class MainActivity extends AppCompatActivity implements LoginFragment.OnFragmentInteractionListener,
        SignUpFragment.OnFragmentInteractionListener, AddExpenseFragment.OnFragmentInteractionListener,
        DetailedFragment.OnFragmentInteractionListener, ExpenseListFragment.OnFragmentInteractionListener {

    Firebase ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkCurrentSession();
    }

    private void goToLoginFragment() {
        getFragmentManager().beginTransaction()
                .add(R.id.container, new LoginFragment(), "Login")
                .commit();
    }

    @Override
    public void goToLoginFragment2() {
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new LoginFragment(), "Login")
                .commit();
    }


    @Override
    public void goToSignUpFragment() {
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new SignUpFragment(), "SignUp")
                .commit();
    }

    @Override
    public void goToExpenseListFragment() {
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new ExpenseListFragment(), "ExpenseList")
                .commit();
    }

    @Override
    public void goToAddExpenseFragment() {
        getFragmentManager().beginTransaction()
                .replace(R.id.container, new AddExpenseFragment(), "AddExpense")
                .commit();
    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            getFragmentManager().popBackStack();
        } else
            super.onBackPressed();
    }

    public void checkCurrentSession() {

        ref = new Firebase("https://inclass12.firebaseio.com/");
        ref.addAuthStateListener(new Firebase.AuthStateListener() {
            @Override
            public void onAuthStateChanged(AuthData authData) {
                if (authData != null) {
                    goToExpenseListFragment();
                } else {
                    goToLoginFragment();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.AddExpense:
                goToAddExpenseFragment();
                return true;
            case R.id.LogOut:
                ref.unauth();
                goToLoginFragment2();
                return true;
            default:
                return true;
        }

    }

    @Override
    public void goToExpenseDetailedFragment(Expense expense) {

        DetailedFragment f = DetailedFragment.newInstance(expense);
        getFragmentManager().beginTransaction().replace(R.id.container, f, "ExpenseDetails").commit();



    }


}
