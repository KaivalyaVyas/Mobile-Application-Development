package com.example.shruj.inclass12;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SignUpFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class SignUpFragment extends Fragment {

    Firebase ref, mRef;
    String email, password, fullname;
    EditText edtEmail, edtPassword, edtFullName;


    private OnFragmentInteractionListener mListener;

    public SignUpFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(false);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sign_up, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void goToLoginFragment2();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getActivity() instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) getActivity();
        } else {
            throw new RuntimeException(getActivity().toString()
                    + " must implement OnFragmentInteractionListener");
        }


        ref = mRef = new Firebase("https://inclass12.firebaseio.com/");

        getActivity().findViewById(R.id.buttonSignUp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtEmail = (EditText) getActivity().findViewById(R.id.EmailSignUp);
                email = edtEmail.getText().toString();

                edtPassword = (EditText) getActivity().findViewById(R.id.PasswordSignUp);
                password = edtPassword.getText().toString();

                edtFullName = (EditText) getActivity().findViewById(R.id.FullNameSignUp);
                fullname = edtFullName.getText().toString();

                ref.createUser(email, password, new Firebase.ValueResultHandler<Map<String, Object>>() {

                    @Override
                    public void onSuccess(Map<String, Object> stringObjectMap) {
                        User u = new User(fullname, email, password);
                        Firebase ref = mRef.child("users").child("" + stringObjectMap.get("uid"));
                        ref.setValue(u);

                        Toast.makeText(getActivity(), "Successfully created new account", Toast.LENGTH_SHORT).show();
                        mListener.goToLoginFragment2();
                    }

                    @Override
                    public void onError(FirebaseError firebaseError) {
                        Toast.makeText(getActivity(), "Account not able to create.", Toast.LENGTH_SHORT).show();

                        switch (firebaseError.getCode()) {
                            case FirebaseError.INVALID_EMAIL:
                                Toast.makeText(getActivity(), "Invalid Email", Toast.LENGTH_SHORT).show();
                                break;
                            case FirebaseError.EMAIL_TAKEN:
                                Toast.makeText(getActivity(), "Email already exists", Toast.LENGTH_SHORT).show();
                                break;
                            default:
                                Toast.makeText(getActivity(), firebaseError.getMessage(), Toast.LENGTH_SHORT).show();
                                break;
                        }
                    }
                });

            }
        });

        getActivity().findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //finish signup and start login fragment
                mListener.goToLoginFragment2();
            }
        });


    }

    public interface OnFragmentTextChange {
        void onTextChanged(String text);
    }
}
