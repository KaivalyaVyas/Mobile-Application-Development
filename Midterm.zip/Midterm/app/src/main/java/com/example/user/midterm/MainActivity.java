package com.example.user.midterm;
/*
Created by user Kaivalya Vyas
800936482
 */
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Spinner spin = null;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spin = (Spinner)findViewById(R.id.spinner_main);
        List<String> cities = new ArrayList<String>();
        /**
         * “Chicago, IL”, ”Atlanta, GA”, “Charlotte, NC”, “San Francisco, CA”, “Seattle, WA”,
         “Orlando, FL”
         */


        cities.add("Chicago, IL");
        cities.add("Atlanta, GA");
        cities.add("Charlotte, NC");
        cities.add("San Francisco, CA");
        cities.add("Seattle, WA");
        cities.add("Orlando, FL");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, cities);

         spin.setAdapter(dataAdapter);

        Button submit = (Button)findViewById(R.id.Submit_Main);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Log.d("KDV", "KDV" + spin.getSelectedItem());
                if(spin.getSelectedItem() != null)
                {
                    intent = new Intent(MainActivity.this, VenusActivity.class);
                    intent.putExtra("Location",spin.getSelectedItem().toString());
                    startActivity(intent);

                }
                else
                {

                                    }

            }
        });



    }
}
