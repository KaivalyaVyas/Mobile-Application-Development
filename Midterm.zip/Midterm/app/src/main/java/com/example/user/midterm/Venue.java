package com.example.user.midterm;

/**
 * Created by user on 3/21/2016.
 */
public class Venue {

String VenueID;
String VenuName;
String  CategiryName;
String  CategoryIcon;
String CheckInCount;

    public String getVenueID() {
        return VenueID;
    }

    public void setVenueID(String venueID) {
        VenueID = venueID;
    }

    public String getVenuName() {
        return VenuName;
    }

    public void setVenuName(String venuName) {
        VenuName = venuName;
    }

    public String getCategiryName() {
        return CategiryName;
    }

    public void setCategiryName(String categiryName) {
        CategiryName = categiryName;
    }

    public String getCategoryIcon() {
        return CategoryIcon;
    }

    public void setCategoryIcon(String categoryIcon) {
        CategoryIcon = categoryIcon;
    }

    public String getCheckInCount() {
        return CheckInCount;
    }

    public void setCheckInCount(String checkInCount) {
        CheckInCount = checkInCount;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
