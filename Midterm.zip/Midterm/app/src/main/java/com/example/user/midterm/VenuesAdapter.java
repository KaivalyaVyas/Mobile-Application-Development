package com.example.user.midterm;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

//import com.squareup.pi

import java.util.List;

/**
 * Created by user on 3/21/2016.
 */
public class VenuesAdapter extends ArrayAdapter<Venue> {

    List<Venue> mData;
    Context mContext;
    int mResource;
    public VenuesAdapter(Context context, int resource, List<Venue> objects) {
        super(context, resource, objects);
        this.mData = objects;
        this.mContext = context;
        this.mResource = resource;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


       ///




        ViewHolder holder;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(mResource, parent, false);

            holder = new ViewHolder();
            holder.textViewNewsTitle = (TextView) convertView.findViewById(R.id.tv1);
            holder.textViewDate = (TextView) convertView.findViewById(R.id.tv2);
            holder.imageView = (ImageView) convertView.findViewById(R.id.iv1);
            holder.imageView2 = (ImageView) convertView.findViewById(R.id.iv2);
            holder.imageView3 = (ImageView) convertView.findViewById(R.id.iv3);

            convertView.setTag(holder);

        }

        Venue venu = mData.get(position);

        holder = (ViewHolder) convertView.getTag();
        TextView textViewNewsTitle = holder.textViewNewsTitle;
        TextView textViewDate = holder.textViewDate;
        ImageView imageView = holder.imageView;
        ImageView imageView2 = holder.imageView2;
        ImageView imageView3 = holder.imageView3;


        textViewNewsTitle.setText(venu.getCategiryName());

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Demo", "");
            }
        });

        textViewDate.setText(venu.getVenuName());




        ///

       /* if (venu.getCategoryIcon() != null) {
            Picasso.with(mContext)
                    .load(forecast.getIconUrl())
                    .fit()
                    .centerInside()
                    .into(imageView);
*/if(Integer.parseInt(venu.getCheckInCount()) <= 100)
        {
            imageView.setImageResource(R.drawable.bronze);
        }

        if(Integer.parseInt(venu.getCheckInCount()) > 100 && Integer.parseInt(venu.getCheckInCount()) <= 500)
        {
            imageView.setImageResource(R.drawable.silver);
        }

        if(Integer.parseInt(venu.getCheckInCount()) > 500)
        {
            imageView.setImageResource(R.drawable.gold);
        }

        return convertView;
    }

    static class ViewHolder {
        TextView textViewNewsTitle;
        TextView textViewDate;
        ImageView imageView;
        ImageView imageView2;
        ImageView imageView3;
    }
}
