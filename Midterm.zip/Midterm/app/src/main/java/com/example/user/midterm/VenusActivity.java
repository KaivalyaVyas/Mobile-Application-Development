package com.example.user.midterm;

import android.app.Activity;
import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import  android.os.*;
import android.widget.ListView;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class VenusActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venus);
       String s = getIntent().getStringExtra("Location");
       // Log.d("KDVin Venus", "" + s);
        VenusAsyncTask asynctAsk = new VenusAsyncTask();
        asynctAsk.execute(s);

    }

    class VenusAsyncTask extends AsyncTask<String,Integer,ArrayList<Venue>>
    {
        ProgressDialog progressDialog;



        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(VenusActivity.this);
            progressDialog.setMessage("Loading Venues");
            progressDialog.setMax(100);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(Boolean.FALSE);
            progressDialog.show();
        }


        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);

        }

        @Override
        protected ArrayList<Venue> doInBackground(String... params) {
            String Location =params[0];
            Date d = new Date();
            /*sysdate logic pending*/


            String ClientID = "NSA3RKQOTDFWK2CQCUTFQ3EAT0OVNWFL0QKFW4KE4UFEOMJR";
            String ClientSecret = "AVPCA0I2IWIKW5LJDYVEMAVJXXMDD1RLC2SOWTN4FP2B3PTI";
           String dateString= "20160321";

           String Link = "https://api.foursquare.com/v2/venues/search?client_id="+ClientID+"&client_secret="+ClientSecret+"&v="+dateString+"&near="+Location;


            try {
                URL url = new URL(Link);
               HttpURLConnection con = (HttpURLConnection)url.openConnection();

                if(con.getResponseCode() == HttpURLConnection.HTTP_OK)
                {

                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line = bufferedReader.readLine();
                    while (line != null) {
                        stringBuilder.append(line);
                        line = bufferedReader.readLine();
                    }

                    try {
                            //Log.d("KDV","in try"+stringBuilder.toString());

                       return VenusJsonUtil.VenusJsonParser.parseVenues(stringBuilder.toString());

                    } catch (JSONException e) {

                        e.printStackTrace();
                        return null;
                    }

                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        }


        @Override
        protected void onPostExecute(ArrayList<Venue> venues) {
            super.onPostExecute(venues);
            progressDialog.dismiss();
          //  Log.d("KDV","inpost"+venues.size());
            setdatainLv(venues);
        }


        public void setdatainLv(List<Venue> venus)
        {
            // TextView tv = (TextView)activity.findViewById(R.id.CurrentLocationV);
            // TextView tv2 = (TextView)activity.findViewById(R.id.CurrentLocationV);



            VenuesAdapter v = new VenuesAdapter(VenusActivity.this, R.layout.row_layout, venus);
            Log.d("KDV","1");
            ListView listView = (ListView) findViewById(R.id.listViewV);
            Log.d("KDV","2");
            listView.setAdapter(v);
            Log.d("KDV", "3");
            v.setNotifyOnChange(Boolean.TRUE);


        }
    }
}
