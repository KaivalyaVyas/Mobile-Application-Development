package com.example.user.midterm;

import android.provider.SyncStateContract;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by user on 3/21/2016.
 */
public class VenusJsonUtil {
    static public class VenusJsonParser
    {
        static ArrayList<Venue> parseVenues(String inputStreamString) throws JSONException
        {

            ArrayList<Venue> arrayListVenues = new ArrayList<>();
            JSONObject jsonObjectRoot = new JSONObject(inputStreamString);
          JSONObject j =  jsonObjectRoot.getJSONObject("response");
            Venue venu = new Venue();

            JSONArray jsonArrayVenues = j.getJSONArray("venues");



            for(int i = 0 ; i<jsonArrayVenues.length();i++)
            {
               JSONObject jobj = (JSONObject)jsonArrayVenues.get(i);
                //JSONArray jsonArrayCat = j.getJSONArray("categories");

                jobj.getString("name");
             //  Log.d("KDV", "id " + jobj.getString("id"));
                venu.setVenueID(jobj.getString("id"));

             //   Log.d("KDV", "name " + jobj.getString("name"));
                venu.setVenuName(jobj.getString("name"));
                JSONArray jsonArrayCat = jobj.getJSONArray("categories");
                for(int k = 0; k < jsonArrayCat.length();k++) {
                    JSONObject jobjCat = (JSONObject)jsonArrayCat.get(k);
                //    Log.d("KDV", "category id " + jobjCat.getString("id"));

                    //Log.d("KDV", "category name " + jobjCat.getString("name"));
                    venu.setCategiryName(jobjCat.getString("name"));
                    JSONObject icon = jobjCat.getJSONObject("icon");
                    String pfix = icon.getString("prefix");
                    String suffix = icon.getString("suffix");
                    //Log.d("KDV"," pfix "+pfix);

                    venu.setCategoryIcon(pfix+"bg_64"+suffix);

                }
              JSONObject stats =  jobj.getJSONObject("stats");
             //   Log.d("KDV","checkin "+stats.getString("checkinsCount"));
                venu.setCheckInCount(stats.getString("checkinsCount"));
                arrayListVenues.add(venu);
            }


             //jsonObjectRoot.getString("");


            return arrayListVenues;
        }
    }
}
